/*
Implementare un server che gestisce una chat tramite protocollo TCP.
Il server attende fino ad un massimo di 10 connessioni.
Ogni volta che accetta una connessione, attende un primo messaggio.
Il contenuto di tale primo messaggio identifica il nickname da associare
al relativo client.
Successivamente, tutti i messaggi inviati dal client verranno
reindirizzati a tutti gli altri client connessi, aggiungendo prima del
messaggio il nickname del client che lo ho scritto.
Esempio:
{
	Tom: Hello there, what's up?
	Luke: Hello Tom. Sorry, I don't have Whatsapp...
	Tom: -.-
}
I client si possono disconnettere quando vogliono. Il server, ogni 30
secondi, invia a tutti i client una lista dei nickname connessi.
Esempio:
{
	***** List of Online Clients *****
	Tom, Luke
	**********************************
}
*/
#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <fcntl.h>

#define MaxPending 10
#define MaxClients 10
#define MaxLenNick 20
#define BufferSize 200
#define ChatInfoSize 1000
#define MessageSize BufferSize + MaxLenNick + 3

typedef struct
{
	int Socket;
	char Nickname[MaxLenNick];
} Client;

void DieWithSystemMessage(const char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

void deltaTime(struct timeval *totalTime, struct timeval *elapsedTime)
{
	long microSeconds = 
		totalTime->tv_usec + (totalTime->tv_sec * 1000000) - 
		elapsedTime->tv_usec - (elapsedTime->tv_sec * 1000000);
		
	totalTime->tv_usec = (microSeconds > 0)? microSeconds : 0;

	totalTime->tv_sec = 0;
}

int main(int argc, char *argv[])
{
	struct sockaddr_in serverAddress, clientAddress;
	int serverSocket, OptVal, maxIndex, maxFD, clientSocket;
	int i, j, k, n, count, numClients;
	char buf[BufferSize], message[MessageSize], chatInfo[ChatInfoSize], *nickname;
	Client client[MaxClients];
	fd_set Rset;
	socklen_t sizeAddress;
	struct timeval timeout, countdown, startTime, endTime;
	
	/* Initialize variables */
	timeout.tv_sec = 30;
	timeout.tv_usec = 0;
	countdown = timeout;
	OptVal = 1;
	numClients = 0;
	maxIndex = -1;
	for (i = 0; i < MaxClients; i++)
	{
		client[i].Socket = -1;
		memset(client[i].Nickname, 0, MaxLenNick);
	}

	/* Get a datagram socket */
	if ((serverSocket = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		DieWithSystemMessage("socket() failed");

	/* Avoid EADDRINUSE error on bind() */
	if (setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, (char *)&OptVal, sizeof(OptVal)) < 0)
		DieWithSystemMessage("setsockopt() failed");

	/* Construct the name */
	memset(&serverAddress, 0, sizeof(serverAddress));
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = htonl(INADDR_ANY);
	serverAddress.sin_port = htons(8000);
	
	/* Bind the socket to the address */
	if (bind(serverSocket, (struct sockaddr *) &serverAddress, sizeof(serverAddress)) < 0)
		DieWithSystemMessage("bind() failed");

	/* Enable incoming connections */
	if (listen(serverSocket, MaxPending) < 0)
		DieWithSystemMessage("listen() failed");
		
	/* Endless loop */
	gettimeofday(&startTime, NULL);
	while (1)
	{
		do
		{
			FD_ZERO(&Rset);
			FD_SET(serverSocket, &Rset);
			maxFD = serverSocket;
			for (i = 0; i <= maxIndex; i++)
			{
				if (client[i].Socket >= 0)
				{
					FD_SET(client[i].Socket, &Rset);
					if (maxFD < client[i].Socket) 
						maxFD = client[i].Socket;
				}
			}
			gettimeofday(&endTime, NULL);
			deltaTime(&endTime, &startTime);
			deltaTime(&countdown, &endTime);
			count = select(maxFD + 1, &Rset, NULL, NULL, &countdown);
			gettimeofday(&startTime, NULL);
		}
		while (count < 0 && errno == EINTR);
		if (count < 0)
			DieWithSystemMessage("select() failed");
		
		if (count == 0)
		{
			countdown = timeout;
			if (numClients == 0)
				continue;
			
			/* Create chat information */
			memset(chatInfo, 0, ChatInfoSize);
			strcpy(chatInfo, "\n------- Online nicks -------\n");
			
			for (j = 0; j <= maxIndex; j++) 
			{
				if (client[j].Socket < 0)
					continue;
				
				strcat(chatInfo, client[j].Nickname);
				if (j < maxIndex)
					strcat(chatInfo, ", ");
			}
			strcat(chatInfo, "\n----------------------------\n");
			
			/* Send info to all clients */
			for (j = 0; j <= maxIndex; j++) 
			{
				if (client[j].Socket < 0)
					continue;
				do
					n = send(client[j].Socket, chatInfo, ChatInfoSize, 0);
				while (n < 0 && errno == EINTR);
				if (n < 0)
					DieWithSystemMessage("send() failed");
			}
			
			continue;
		}
		
		/* New client connection */
		if (numClients < MaxClients && FD_ISSET(serverSocket, &Rset))
		{
			/* Accept connection */
			sizeAddress = sizeof(clientAddress);
			clientSocket = accept(serverSocket, (struct sockaddr *) &clientAddress, &sizeAddress);
			
			/* Save client socket */
			for (i = 0; client[i].Socket != -1; i++);
			client[i].Socket = clientSocket;
			if (i > maxIndex)
				maxIndex = i;
			
			/* Wait to nickname */
			memset(buf, 0, BufferSize);
			do
				n = recv(clientSocket, buf, BufferSize, 0);
			while (n < 0 && errno == EINTR);
			if (n < 0)
				DieWithSystemMessage("recv() failed");
			
			nickname = client[i].Nickname;
			for (j = 0; buf[j] && buf[j] != '\n'; j++)
				nickname[j] = buf[j];

			numClients++;
			count--;
		}

		/* Check all clients for data */
		for (i = 0; i <= maxIndex && count > 0; i++)
		{
			if ((clientSocket = client[i].Socket) < 0)
				continue;
			
			if (FD_ISSET(clientSocket, &Rset))
			{
				/* Receive the message */
				memset(buf, 0, BufferSize);
				do
					n = recv(clientSocket, buf, BufferSize, 0);
				while (n < 0 && errno == EINTR);
				if (n < 0)
					DieWithSystemMessage("recv() failed");
					
				/* Connection closed by client */
				if (n == 0)
				{
					close(clientSocket);
					client[i].Socket = -1;
					memset(client[i].Nickname, 0, MaxLenNick);
					numClients--;
				}
				else
				{
					/* Create the message */
					memset(message, 0, MessageSize);
					sprintf(message, "%s: %s\n", nickname, message);
					
					/* Re-transmit message to all other clients */
					for (j = 0; j <= maxIndex; j++) 
					{
						if (j == i || client[j].Socket < 0)
							continue;
						do
							n = send(client[j].Socket, message, MessageSize, 0);
						while (n < 0 && errno == EINTR);
						if (n < 0)
							DieWithSystemMessage("send() failed");
					}
				}
				count--;
			}
		}
	}

	/* Clean up and close */
	close(serverSocket);
	return(0);
}
