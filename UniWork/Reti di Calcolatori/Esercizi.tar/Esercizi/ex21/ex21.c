/*
 * Un server gestisce max 5 connessioni TCP contemporaneamente.
 * I client spediscono numeri, i numeri pari vengono inviati a 
 * tutti gli altri client. I numeri dispari vengono sommati fino a quando
 * non si raggiunge 100, a quel punto le connessioni vengono chiuse
 * e il server termina.
*/
#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <fcntl.h>

#define MaxPending 5
#define MaxConnections 5
#define BufferSize 100
#define MaxNumber 100

typedef struct
{ 
	int Socket;
	struct sockaddr_in Address;
} Client;

void DieWithSystemMessage(char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

void DieWithUserMessage(char *message)
{
	printf("%s\n", message);
	exit(EXIT_FAILURE);
}

int main (int argc, char *argv[])
{
	int i, j, count, maxIndex, maxFD, numClients, totalSum, serverSocket, clientSocket, number;
	char num[BufferSize], buf[BufferSize];
	ssize_t n;
	fd_set Rset;
	socklen_t length;
	struct sockaddr_in clientAddress, serverAddress;
	Client client[MaxConnections];
	totalSum = numClients = 0;
	
	/* Check parameters */
	if (argc != 2)
		DieWithUserMessage("Wrong number of parameters.");

	/* Get TCP socket */
	if ((serverSocket = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		DieWithSystemMessage("socket() failed");

	/* Construct server address */
	memset(&serverAddress, 0, sizeof(serverAddress));
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = htonl(INADDR_ANY);
	serverAddress.sin_port = htons(atoi(argv[1]));

	/* Bind socket to address */
	if (bind(serverSocket, (struct sockaddr *) &serverAddress, sizeof(serverAddress)) < 0) 
		DieWithSystemMessage("bind() failed");

	/* Enable incoming connections */
	if (listen(serverSocket, MaxPending) < 0) 
		DieWithSystemMessage("listen() failed");

	/* Initialize variables */
	maxFD = serverSocket;
	maxIndex = -1;
	for (i = 0; i < MaxConnections; i++)
		client[i].Socket = -1;
		
	while (totalSum < MaxNumber) 
	{
		do
		{
			/* Populate FD sets */
			FD_ZERO(&Rset);
			FD_SET(serverSocket, &Rset);
			maxFD = serverSocket;
			printf("maxIndex = %d\n", maxIndex);
			for (i = 0; i <= maxIndex; i++)
			{
				printf("i = %i, maxIndex = %d\n", i, maxIndex);
				if (client[i].Socket >= 0)
				{
					FD_SET(client[i].Socket, &Rset);
					if (maxFD < client[i].Socket) 
						maxFD = client[i].Socket;
				}
			}
			/* Wait for I/0 events */
			count = select(maxFD + 1, &Rset, NULL, NULL, NULL);
		} 
		while (count < 0 && errno == EINTR);
		if (count < 0)
			DieWithSystemMessage("select() failed");

		/* New client connection */
		if (FD_ISSET(serverSocket, &Rset) && numClients < MaxConnections)
		{ 
			/* Accept connection */
			length = sizeof(struct sockaddr_in);
			clientSocket = accept(serverSocket, (struct sockaddr *) &clientAddress, &length);
			
			/* Get client info */
			for (i = 0; i < MaxConnections && client[i].Socket >= 0; i++);
			numClients++;
			client[i].Socket = clientSocket;
			client[i].Address = clientAddress;

			/* Update max index */
			if (i > maxIndex)
				maxIndex = i;
				
			/* Update events count */
			if (--count <= 0)
				continue;
		}
		
		/* Check all clients for data */
		for (i = 0; i <= maxIndex && count > 0; i++)
		{
			if ((clientSocket = client[i].Socket) < 0)
				continue;
				
			/* Incoming data */
			if (FD_ISSET(clientSocket, &Rset))
			{ 
				
				do
					n = recv(clientSocket, buf, BufferSize, 0);
				while (n < 0 && errno == EINTR);
				
				/* Connection closed by client */
				if (n == 0)
				{
					close(clientSocket);
					client[i].Socket = -1;
				} 
				/* Connection error */
				else if (n < 0)
				{
					printf("Error detected from socket %d\n", clientSocket);
					close(clientSocket);
					client[i].Socket = -1;
				}
				else
				{
					/* Parse message to natural number */
					memset(num, 0, BufferSize);
					for (j = 0; j < BufferSize && buf[j] >= '0' && buf[j] <= '9'; j++)
						num[j] = buf[j];
					number = atoi(num);
					printf("number = %d\n", number);
					/* Even number */
					if (number % 2 == 0)
					{
						for (j = 0; j <= maxIndex; j++)
						{
							if (j == i) continue;
							do
								n = send(client[j].Socket, num, BufferSize, 0);
							while (n < 0 && errno == EINTR);
						}
					}
					/* Odd number */
					else
						totalSum += number;
				}
				count--;
				continue;
			}
		}
	}
	
	/* Clean up and exit */
	for (i = 0; i <= maxIndex; i++)
		close(client[i].Socket);
	close(serverSocket);
	printf("Done!\n");
	exit(EXIT_SUCCESS);
}
