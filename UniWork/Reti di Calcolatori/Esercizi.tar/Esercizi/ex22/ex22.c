/*
 * Un client riceve in input un massimo di 5 indirizzi a cui connettersi.
 * Si tratta di tuple (address, port number).
 * Invia, ad ogni connessione riuscita, in parallelo, mediante protocollo
 *  UDP, il numero 10.
 * Attende la risposta, se la risposta e' un numero negativo o 0, il client
 * termina. Altrimenti re-invia il numero decrementato di 1. Quando il numero
 * giunge a 0, il client termina. 
*/
#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>

#define MaxConnections 5
#define StartNumber 10
#define BufferSize 100

int setNonBlocking(int socket)
{
	int flags;
	if ((flags = fcntl(socket, F_GETFL, 0)) < 0) 
		return 0;
	flags |= O_NONBLOCK;
	if (fcntl(socket, F_SETFL, flags) < 0) 
		return 0;
	return 1;
}

typedef struct
{
	char RemoteAddress[BufferSize];
	short int RemotePort;
	int Socket;
} Connection;

void DieWithUserMessage(const char *message)
{
	printf("%s\n", message);
	exit(EXIT_FAILURE);
}

void DieWithSystemMessage(const char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

void ThreadError(const char *message)
{
	perror(message);
	pthread_exit(NULL);
}

void *ThreadHandler(void *parameter)
{
	int i, number, count, *returnValue;
	unsigned int size;
	struct sockaddr_in remoteAddress;
	Connection *connection;
	char message[BufferSize], numeric[BufferSize];
	
	number = StartNumber;
	connection = (Connection *) parameter;
	
	/* Construct destination address */
	remoteAddress.sin_family = AF_INET;
	remoteAddress.sin_addr.s_addr = inet_addr(connection->RemoteAddress);
	remoteAddress.sin_port = htons(connection->RemotePort);

	printf("%s\n", connection->RemoteAddress);
	printf("%d\n", connection->RemotePort);
	/* Connection request */
	if (connect(connection->Socket, (struct sockaddr *) &remoteAddress,  sizeof(remoteAddress)) < 0)
		ThreadError("connect() failed");

	/* Send number to server */
	memset(message, 0, BufferSize);
	sprintf(message, "%d", number);
	if (sendto(connection->Socket, message, BufferSize + 1 , 0, (struct sockaddr *) &remoteAddress, sizeof(remoteAddress)) < 0)
	{
		close(connection->Socket);
		ThreadError("sendto() failed");
	}
	printf("%s\n", message);
	/* Wait for response */
	memset(&remoteAddress, 0, sizeof(remoteAddress));
	size = sizeof(remoteAddress);
	count = recvfrom(connection->Socket, message, BufferSize, 0, (struct sockaddr *) &remoteAddress, &size);
	if (count < 0)
	{
		close(connection->Socket);
		ThreadError("recvfrom() failed");
	}
	
	/* Parse reponse */
	memset(numeric, 0, BufferSize);
	for (i = 0; i < BufferSize && (message[i] == '-' || (message[i] >= '0' && message[i] <= '9')); i++)
		numeric[i] = message[i];
	number = atoi(numeric);
	
	if (number <= 0)
	{
		printf("-");
	}
	else
	{
		printf("+");
	}

	/* Clean up and exit */
	free(parameter);
	close(connection->Socket);
	if (!(returnValue = malloc(sizeof(int))))
		ThreadError("malloc() failed");

	*returnValue = 1;
	pthread_exit(returnValue);
}

int main (int argc, char *argv[])
{
	int i, option, *returnValue;
	struct sockaddr_in clientAddress;
	/*struct timeval timeout;*/
	int numConnections;
	pthread_t vthreads[MaxConnections];
	Connection *connection;

	/*timeout.tv_sec = 1;
	timeout.tv_usec = 0;*/

	/* Check number of parameters */
	if (argc == 1 || (argc - 1) % 2 != 0 || (argc - 1) / 2 > 5)
		DieWithUserMessage("Wrong number of parameters.");

	numConnections = (argc - 1) / 2;
	
	/* Construct local address */
	memset(&clientAddress, 0, sizeof(clientAddress));
	clientAddress.sin_family = AF_INET;
	clientAddress.sin_addr.s_addr = htonl(INADDR_ANY);
	clientAddress.sin_port = htons(0);	
	
	/* Create a thread for each connection */
	for (i = 0; i < numConnections; i++)
	{
		/* Build thread parameter */
		if (!(connection = malloc(sizeof(Connection))))
			DieWithSystemMessage("malloc() failed");
			
		connection->RemotePort = atoi(argv[(i * 2) + 2]);
		strcpy(connection->RemoteAddress, argv[(i * 2) + 1]);
		
		/* Get a datagram socket */
		if ((connection->Socket = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
			DieWithSystemMessage("socket() failed");

		/* Avoid EADDRINUSE error on bind() */
		option = 1;
		if (setsockopt(connection->Socket, SOL_SOCKET, SO_REUSEADDR, (char *) &option, sizeof(option)) < 0)
			DieWithSystemMessage("setsockopt() failed");

		/* Bind socket to address */
		if (bind(connection->Socket, (struct sockaddr *) &clientAddress, sizeof(clientAddress)) < 0)
			DieWithSystemMessage("bind() failed");
		
		/* Spawn thread */
		if (pthread_create(&vthreads[i], NULL, ThreadHandler, connection))
			DieWithSystemMessage("pthread_create() failed");
	}
	
	/* Wait for threads to terminate */
	for (i = 0; i < MaxConnections; i++)
	{
		if (pthread_join(vthreads[i], (void *) &returnValue))
			DieWithSystemMessage("pthread_join() failed");

		free(returnValue);
	}
	pthread_exit(NULL);
}
