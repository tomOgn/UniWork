/*
Il server attende 5 connessioni. Attende i primi 5 messaggi.
Accetta al massimo 2 messaggi per ogni connessione, al secondo
messaggio ricevuto chiude quella connessione con un messaggio di OK.
Alla fine chiude tutte le connessioni. Ritorna i messaggi concatenati.
*/

#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <fcntl.h>

#define MaxConnections 2
#define BufferSize 100
#define MaxTotalMessages 5
#define MaxPending MaxConnections
#define MaxMessagesPerClient 2

typedef struct sockaddr SA;

typedef struct
{ 
	int Socket;
	int MessageCount;
} Client;

void DieWithUserError(const char *message)
{
	printf("%s\n", message);
	exit(EXIT_FAILURE);
}

void DieWithSystemError(const char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

int main(int argc, char *argv[])
{
	short int serverPort;
	int i, count, maxIndex, maxFD, serverSocket, clientSocket, numConnections, messageCount;
	fd_set Rset, Wset;
	socklen_t size;
	struct sockaddr_in cliaddr, serverAddress;
	Client clients[MaxConnections];
	char message[MaxTotalMessages][BufferSize], buf[BufferSize];
	
	/* Check number of parameters */
	if (argc != 2)
		DieWithUserError("Two parameters needed.");

	serverPort = atoi(argv[1]);

	/* Get TCP socket */
	if ((serverSocket = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		DieWithSystemError("socket() failed");

	/* Construct server address */
	memset(&serverAddress, 0, sizeof(serverAddress));
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = htonl(INADDR_ANY);
	serverAddress.sin_port = htons(serverPort);
	
	/* Bind socket to address */
	if (bind(serverSocket, (SA *) &serverAddress, sizeof(serverAddress)) < 0)
		DieWithSystemError("bind() failed");
	
	/* Enable incoming connections */
	if (listen(serverSocket, MaxPending) < 0)
		DieWithSystemError("listen() failed");
		
	/* Initialize variables */
	maxFD = serverSocket;
	maxIndex = -1;
	for (i = 0; i < MaxConnections; i++) 
	{
		clients[i].Socket = -1;
		clients[i].MessageCount = 0;
	}
	messageCount = numConnections = 0;
	
	/* Iterate until MaxTotalMessages are received */
	while (messageCount < MaxTotalMessages) 
	{
		/* Build socket sets and wait for an event */
		do
		{
			FD_ZERO(&Rset);
			FD_ZERO(&Wset);
			FD_SET(serverSocket, &Rset);
			maxFD = serverSocket;

			for (i = 0; i <= maxIndex; i++)
			{
				if (clients[i].Socket >= 0)
				{
					FD_SET(clients[i].Socket, &Rset);
					if (maxFD < clients[i].Socket) 
						maxFD = clients[i].Socket;
				}
			}
			count = select(maxFD + 1, &Rset, &Wset, NULL, NULL);
		}
		while (count < 0 && errno == EINTR);

		if (count < 0)
			DieWithSystemError("select() failed");

		/* New client connection */
		if (numConnections < MaxConnections && FD_ISSET(serverSocket, &Rset))
		{
			numConnections++;
			size = sizeof(cliaddr);
			
			/* Accept client connection */
			if ((clientSocket = accept(serverSocket, (SA *) &cliaddr, &size)) < 0)
				DieWithSystemError("accept() failed");
			
			/* Update clients vector */
			for (i = 0; i < MaxConnections; i++) 
			{
				if (clients[i].Socket < 0)
				{
					clients[i].Socket = clientSocket;
					clients[i].MessageCount = 0;
					break;
				}
			}

			/* Update max index */
			if (i > maxIndex)
				maxIndex = i; 

			/* No more events */
			if (--count <= 0)
				continue; 
		}
		
		/* Check all clients for data */
		for (i = 0; i <= maxIndex && count > 0; i++)
		{
			if ((clientSocket = clients[i].Socket) < 0)
				continue;

			/* Available message to be received */
			if (FD_ISSET(clientSocket, &Rset)) 
			{
				memset(buf, 0, BufferSize);
				do
					count = recv(clientSocket, buf, BufferSize, 0);
				while (count < 0 && errno == EINTR);
				
				/* Connection closed by client */
				if (count == 0)
				{
					close(clientSocket);
					clients[i].Socket = -1;
					numConnections--;
				}
				/* Connection error */
				else if (count < 0)
				{
					printf("Error detected from socket %d\n", clientSocket);
					close(clientSocket);
					clients[i].Socket = -1;
					numConnections--;
				}
				else
				{
					buf[count] = (char) 0;
					clients[i].MessageCount++;
					strcpy(message[messageCount], buf);
					messageCount++;
					if (clients[i].MessageCount == MaxMessagesPerClient)
					{
						/* Send message to client */
						memset(buf, 0, BufferSize);
						strcpy(buf, "Received 2 messages from you. That's enough. Thank you.\n");
						do
							count = send(clients[i].Socket, buf, BufferSize, MSG_NOSIGNAL | MSG_DONTWAIT);
						while (count < count && errno == EINTR);
						
						/* Connection error */
						if (count < 0)
							printf("Error detected from socket %d\n", clients[i].Socket);
						
						close(clients[i].Socket);
						clients[i].Socket = -1;
						numConnections--;
					}
				}
				count--;
			}
		}
	}
	
	/* Print output */
	printf("Message concatenation:\n");
	for (i = 0; i < MaxTotalMessages; i++)
		printf("%s", message[i]);
	printf("\n");
	
	/* Clean up and exit */
	for (i = 0; i < maxIndex; i++)
		if (clients[i].Socket != -1)
			close(clients[i].Socket);
	close(serverSocket);
	exit(EXIT_SUCCESS);
}
