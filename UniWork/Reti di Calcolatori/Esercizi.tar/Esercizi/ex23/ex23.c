/*
Il client riceve in input un massimo di 10 parametri nella forma
(address, port number).
In modo parallelo, mediante protocollo UDP, invia ad ogni server 
un messaggio di saluto.
I server rispondono con un numero naturale.
Se il numero e' dispari, ripete il messaggio di saluto, altrimenti chiude la
connessione.
Quando tutte le connessioni sono terminate, il client termina ritornando
la somma complessiva dei numeri pari ricevuti.
*/

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <pthread.h>

#define BufferSize (int) 100
#define MaxConnections 5

struct sockaddr_in LocalAddress;

typedef struct
{
	char Address[BufferSize];
	short int Port;
} Server;

void ThreadError(const char *message)
{
	perror(message);
	pthread_exit(NULL);
}

void DieWithSystemError(const char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

void DieWithUserError(const char *message)
{
	printf("%s\n", message);
	exit(EXIT_FAILURE);
}

void *ThreadHandler(void *parameter)
{
	struct sockaddr_in remoteAddress;
	int i, localSocket, value, length, number, *returnValue;
	char message[BufferSize], numeric[BufferSize];
	unsigned int SizeAddress;
	Server *server;
	
	/* Initialize variables */
	SizeAddress = sizeof(struct sockaddr_in);
	server = (Server *) parameter;
	
	/* Get a datagram socket */
	if ((localSocket = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
		DieWithSystemError("socket() failed");

	value = 1;
	if (setsockopt(localSocket, SOL_SOCKET, SO_REUSEADDR, (char *) &value, sizeof(value)) < 0)
		DieWithSystemError("socket() failed");
	
	/* Bind socket to address */
	if (bind(localSocket, (struct sockaddr *) &LocalAddress, SizeAddress) < 0)
		DieWithSystemError("bind() failed");

	/* Construct remote address */
	memset(&remoteAddress, 0, SizeAddress);
	remoteAddress.sin_family = AF_INET;
	remoteAddress.sin_addr.s_addr = inet_addr(server->Address); 
	remoteAddress.sin_port = htons(server->Port);

	/* Connection request */
	if (connect(localSocket, (struct sockaddr *) &remoteAddress, SizeAddress) < 0)
		DieWithSystemError("connect() failed");
	
	/* Try until the receiver sends back an even number */
	do
	{
		/* Send to remote address */
		memset(message, 0, sizeof(message));
		SizeAddress = sizeof(struct sockaddr_in);
		strcpy(message, "Hello there! Give me an even number:\n");
		if (sendto(localSocket, message, strlen(message) + 1 , 0, (struct sockaddr *) &remoteAddress, SizeAddress) < 0)
			DieWithSystemError("sendto() failed");
		
		/* Wait for answer */
		memset(message, 0, sizeof(message));
		memset(&remoteAddress, 0, sizeof(remoteAddress));
		if ((length = recvfrom(localSocket, message, BufferSize, 0, (struct sockaddr *) &remoteAddress, &SizeAddress)) < 0)
			DieWithSystemError("recvfrom() failed");
		
		/* Parse answer */
		for (i = 0; message[i] && message[i] >= '0' && message[i] <= '9'; i++)
			numeric[i] = message[i];
		number = atoi(numeric);
	}
	while (number % 2 != 0);
	
	/* Clean up and exit */
	free(parameter);
	close(localSocket);
	returnValue = malloc(sizeof(int));
	if (!returnValue)
		ThreadError("malloc() failed");
	*returnValue = number;
	pthread_exit(returnValue);
}

int main(int argc, char *argv[])
{
	int i, numConnections, *returnValue, sum;
	Server *server;
	pthread_t *threads;
	
	/* Check number of parameters */
	if ((argc - 1) % 2 != 0 || (argc - 1) == 0 || (argc - 1) / 2 > MaxConnections)
		DieWithUserError("Wrong number of parameters");

	/* Construct local address */
	memset(&LocalAddress, 0, sizeof(LocalAddress));
	LocalAddress.sin_family = AF_INET;
	LocalAddress.sin_addr.s_addr = inet_addr("127.0.0.1"); 
	LocalAddress.sin_port = htons(5000);

	/* Create the connections */
	numConnections = (argc - 1) / 2;
	threads = (pthread_t *) malloc(numConnections * sizeof(pthread_t));
	if (!threads)
		DieWithSystemError("malloc() failed");
	for (i = 0; i < numConnections; i++)
	{
		/* Build thread parameter */
		server = malloc(sizeof(Server));
		if (!server)
			DieWithSystemError("malloc() failed");
		memset(server->Address, 0, BufferSize);
		server->Port = atoi(argv[(i * 2) + 2]);
		strcpy(server->Address, argv[(i * 2) + 1]);
		
		/* Spawn thread */
		if (pthread_create(&threads[i], NULL, ThreadHandler, server))
			DieWithSystemError("pthread_create() failed");
	}
	
	sum = 0;
	/* Wait for threads to terminate */
	for (i = 0; i < numConnections; i++)
	{
		if (pthread_join(threads[i] , (void *) &returnValue))
			DieWithSystemError("pthread_join() failed");
		sum += *((int *) returnValue);
		free(returnValue);
	}
	
	printf("Sum = %d\n", sum);
	pthread_exit(NULL);
}
