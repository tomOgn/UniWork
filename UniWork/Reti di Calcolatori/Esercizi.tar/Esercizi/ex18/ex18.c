/*
Creare un token ring di threads. 
*/

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>

#define BufferSize 100

typedef struct
{
	int From, To;
} RingNode;

/* Global variables */
RingNode *Nodes;

void DieWithSystemError(const char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

void *ThreadHandler(void *parameter)
{
	char token[1];
	int index, count;
	
	index = *((int *) parameter);
	
	/* Wait the token */
	do
		count = read(Nodes[index].To, token, 1);
	while (count < 0 && errno == EINTR);
	if (count < 0)
		DieWithSystemError("read() failed");
	
	printf("[%d] I have the token\n", (int) pthread_self());
	
	/* Send the token */
	do
		count = send(Nodes[index].From, token, 1, MSG_NOSIGNAL);
	while (count < 0 && errno == EINTR);
	if (count < 0)
		DieWithSystemError("send() failed");
	
	/* Clean up and exit */
	free(parameter);
	pthread_exit(NULL);
}

int main(int argc,char** argv)
{
	int fd[2], i, *parameter, to, count, size, numNodes;
	char *token;
	pthread_t *threads;
	pthread_attr_t attr;
	
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	
	numNodes = atoi(argv[1]);
	Nodes = (RingNode *) malloc(numNodes * sizeof(RingNode));
	threads = (pthread_t *) malloc(numNodes * sizeof(pthread_t));
	if (!Nodes || !threads)
		DieWithSystemError("malloc() failed");
	
	/* Create the token ring */
	for (i = 0; i < numNodes; i++)
	{
		/* Create the socket pairs */
		if (socketpair(AF_UNIX, SOCK_STREAM, 0, fd) < 0)
			DieWithSystemError("socketpair() failed");
		Nodes[i].From = fd[0];
		if (i > 0)
			Nodes[i].To = to;
		to = fd[1];
		
		/* Spawn the thrads */
		parameter = malloc(sizeof(int));
		if (!parameter)
			DieWithSystemError("malloc() failed");
		*parameter = i;
		if (pthread_create(&(threads[i]), &attr, ThreadHandler, parameter))
			DieWithSystemError("pthread_create() failed");
			
	}
	Nodes[0].To = to;
	
	/* Trigger the token ring */
	token = "1";
	size = 2;
	do
		count = send(to, token, size, MSG_NOSIGNAL);
	while (count < 0 && errno == EINTR);
	if (count < 0)
		DieWithSystemError("send() failed");
	
	/* Clean up and exit */
	pthread_attr_destroy(&attr);
	pthread_exit(NULL);
}
