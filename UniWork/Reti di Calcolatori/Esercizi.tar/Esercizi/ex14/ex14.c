/*
Definire un SERVER TCP che consente N connessioni a CLIENT.
Gestisce le nuove connessioni e la ricezione di dati dai CLIENT mediante la funzione select().
Quando un CLIENT manda un messaggio, il SERVER crea un THREAD apposito che lo gestisce.
Ogni THREAD riceve un numero intero positivo, calcola se e' pari o dispari, risponde al CLIENT,
termina la connessione e si auto-elimina.
*/

#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>

#define BufferSize 100
#define MaxPending 10

/* Global variables */
int Client[FD_SETSIZE];

void DieWithSystemMessage(char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

void *ThreadHandler(void *parameter)
{
	int index, count, clientSocket;
	char buffer[BufferSize];

	index = *((int*)parameter);
	clientSocket = Client[index];
	
	memset(buffer, 0, sizeof(buffer));
    do
    	count = recv(clientSocket, buffer, BufferSize, 0);
    while(count < 0 && errno == EINTR);
    if (count < 0)
    	DieWithSystemMessage("recv() failed");

	printf("%s\n", buffer);
 
 	if (close(clientSocket) < 0)
 		DieWithSystemMessage("close() failed");
	Client[index] = -1;

	free(parameter);
	pthread_exit(NULL);
}

int main (int argc, char *argv[])
{
	short int localPort;
	int maxFD, numClients, *parameter, i, maxIndex, serverSocket, clientSocket, count;
	fd_set activeSet;
	socklen_t size;
	struct sockaddr_in clientAddress, serverAddress;
	pthread_t threads[FD_SETSIZE];
	pthread_attr_t attr;

	if (argc != 2)
	{
		printf ("Wrong parameters\n");
		exit(EXIT_FAILURE);
	}

	localPort = atoi(argv[1]);

	/* Get server socket */
	if ((serverSocket = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		DieWithSystemMessage("socket() failed");
    
    /* Construct server address */
	memset(&serverAddress, 0, sizeof(serverAddress));
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = htonl(INADDR_ANY);
	serverAddress.sin_port = htons(localPort);

	/* Bind server socket to server address */
	if (bind(serverSocket, (struct sockaddr *) &serverAddress, sizeof(serverAddress)) < 0) 
		DieWithSystemMessage("bind() failed");

	/* Enable incoming connections */
	if (listen(serverSocket, MaxPending) < 0)
		DieWithSystemMessage("bind() failed");	

	/* Initialize variables */
    maxFD = serverSocket;
    maxIndex = -1;
    for (i = 0; i < FD_SETSIZE; i++)
	    Client[i] = -1;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

    while (1) 
    {
    	/* Build the set of clients */
		maxFD = serverSocket;
		numClients = 0;
		FD_ZERO(&activeSet);
    	FD_SET(serverSocket, &activeSet);
		for (i = 0; i <= maxIndex; i++)
		{
			if (Client[i] >= 0)
			{
				FD_SET(Client[i], &activeSet);
				if (Client[i] > maxFD)
					maxFD = Client[i];
				numClients++;
			}
		}

		/* Wait for events on sockets */
		do
			count = select(maxFD + 1, &activeSet, NULL, NULL, NULL);
		while (count < 0 && errno == EINTR);
		if (count < 0)
			DieWithSystemMessage("select() failed");				

		/* New client connection */
		if (FD_ISSET(serverSocket, &activeSet) && numClients < FD_SETSIZE)
		{
			size = sizeof(clientAddress);
			if ((clientSocket = accept(serverSocket, (struct sockaddr *) &clientAddress, &size)) < 0)
				DieWithSystemMessage("accept() failed");	    	

			numClients++;

			for (i = 0; Client[i] >= 0; i++);
			Client[i] = clientSocket;

			if (i > maxIndex)
				maxIndex = i;
			count--;
		}
		/* New data sent by a client or a connection closed */
		for (i = 0; i <= maxIndex && count > 0 ; i++)
		{
			clientSocket = Client[i];

			if (clientSocket < 0)
				continue;

			if (FD_ISSET(clientSocket, &activeSet))
			{ 
				/* Build thread parameter */
				if(!(parameter = malloc(sizeof(int))))
					DieWithSystemMessage("malloc() failed");
				*parameter = i;

				/* Spawn thread */
				if (pthread_create(&threads[i], &attr, ThreadHandler, parameter))
					DieWithSystemMessage("pthread_create() failed");

				count--;
			}
		}
	}
	pthread_attr_destroy(&attr);
	pthread_exit(NULL);
} 