#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>

#define MessageSize 1000002
#define TabuSize 5
#define ServerAddress "127.0.0.5"
#define ServerPort 8000
#define MetadataSize 1000

void DieWithSystemMessage(const char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

int GetTCPSocket(char *address, int port)
{
	int theSocket, value;
	struct sockaddr_in serverAddress;
	
	/* Get a datagram socket */
	if ((theSocket = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		DieWithSystemMessage("socket() failed");
		
	/* Avoid EADDRINUSE error on bind() */
	value = 1;
	if (setsockopt(theSocket, SOL_SOCKET, SO_REUSEADDR, (char *) &value, sizeof(value)) < 0)
		DieWithSystemMessage("setsockopt() failed");
		
	/* Construct the address */
	memset(&serverAddress, 0, sizeof(serverAddress));
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = inet_addr(address);
	serverAddress.sin_port = htons(port);
	
	/* Bind socket to address */
	if (bind(theSocket, (struct sockaddr *) &serverAddress, sizeof(serverAddress)) < 0)
		DieWithSystemMessage("bind() failed");
		
	return theSocket;
}

int main(int argc, char *argv[])
{
	struct sockaddr_in serverAddress;
	int clientSocket, i, sizeAddress, numTabu;
	char size[MetadataSize], message[MessageSize], tabu[TabuSize + 1], metadata[MetadataSize];
	
	/* Initialize variables */
	strcpy(tabu, "vaffa");
	tabu[TabuSize] = 0;
	memset(message, 0, MessageSize);
	memset(size, 0, MetadataSize);
	numTabu = (MessageSize - 2) / TabuSize;
	for (i = 0; i < numTabu; i++)
		strcat(message, tabu);
	message[MessageSize - 2] = '1';
	sizeAddress = sizeof(serverAddress);
	clientSocket = GetTCPSocket("0.0.0.0", 0);
	memset(metadata, 0, MetadataSize);
	metadata[0] = 'S';
	sprintf(size, "%d", MessageSize);
	strcat(metadata, size);
	
	/* Construct destination address */
	memset(&serverAddress, 0, sizeAddress);
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = inet_addr(ServerAddress);
	serverAddress.sin_port = htons(ServerPort);

	/* Connection request */
	if (connect(clientSocket, (struct sockaddr *) &serverAddress, sizeAddress) < 0)
		DieWithSystemMessage("connect() failed");

	/* Send metadata */
	if (send(clientSocket, metadata, MetadataSize, 0) < 0)
		DieWithSystemMessage("send() failed");
	
	/* Send data */
	if (send(clientSocket, message, MessageSize, 0) < 0)
		DieWithSystemMessage("send() failed");

	/* Clean up and close */
	if (close(clientSocket) < 0)
		DieWithSystemMessage("close() failed");
	exit(EXIT_SUCCESS);
}
