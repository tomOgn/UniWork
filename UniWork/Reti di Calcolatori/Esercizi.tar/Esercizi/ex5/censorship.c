/*
Costruire un'applicazione server "Censorship" che esegue le seguenti operazioni:
(1)	Accetta la richiesta di connessione di un client SENDER.
	Il primo messaggio del client SENDER comprende il flag SENDER e il
	numero di bytes che verrano spediti.
(2)	Accetta la richiesta di connessione per un client RECEIVER.
	Il primo messaggio del client RECEIVER comprende il flag RECEIVER.
(3)	Riceve ogni messaggio spedito dal SENDER e lo censura. Segnatamente, elimina
	dal messaggio tutte le occorrenze della parola "vaffa".
(4)	Invia il messaggio censurato al RECEIVER.
Inoltre:
(*) Il protocollo di trasporto da utilizzare e' il TCP.
(*) La dimensione del buffer per il messaggio e' dimensionata in base al 
metadato fornito dal SENDER.
(*) Il punto (2) potrebbe precedere il punto (1). A seconda della richiesta 
di connessione che arriva per prima.
Oggetti da implementare:
(1)	Il file censorship.c che gestisce il server.
(2)	Il file sender.c che gestisce il sender.
	Questo deve inviare un messaggio di 1000002 di bytes costituito da
	20000 "vaffa" concatenati (20000 * 5 = 1000000) + il carattere '1' +
	il carattere terminatore '\0'.
(3)	Il file receiver.c che gestisce il receiver.
L'esecuzione dei 3 programmi deve fare in modo che il receiver riceva solamente
il messaggio "1".
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>

#define MaxPending 10
#define BufferSize 1000
#define TabuSize 5
#define ServerAddress "127.0.0.5"
#define ServerPort 8000

void DieWithSystemMessage(const char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

int GetTCPSocket()
{
	int theSocket, value;
	struct sockaddr_in serverAddress;
	
	/* Get a datagram socket */
	if ((theSocket = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		DieWithSystemMessage("socket() failed");
		
	/* Avoid EADDRINUSE error on bind() */
	value = 1;
	if (setsockopt(theSocket, SOL_SOCKET, SO_REUSEADDR, (char *) &value, sizeof(value)) < 0)
		DieWithSystemMessage("setsockopt() failed");
		
	/* Construct the address */
	memset(&serverAddress, 0, sizeof(serverAddress));
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = inet_addr(ServerAddress);
	serverAddress.sin_port = htons(ServerPort);
	
	/* Bind socket to address */
	if (bind(theSocket, (struct sockaddr *) &serverAddress, sizeof(serverAddress)) < 0)
		DieWithSystemMessage("bind() failed");
		
	/* Enable incoming connections */
	if (listen(theSocket, MaxPending) < 0)
		DieWithSystemMessage("listen() failed");
		
	return theSocket;
}

int main(int argc, char *argv[])
{
	struct sockaddr_in clientAddress;
	int serverSocket, clientSocket, senderSocket, receiverSocket;
	unsigned int sizeAddress, i, j, length;
	char SenderFlag, ReceiverFlag, buffer[BufferSize], *number, *originalMessage, *censoredMessage, tabu[TabuSize + 1], chunk[TabuSize + 1];
	
	/* Initialize variables */
	memset(tabu, 0, TabuSize + 1);
	strcpy(tabu, "vaffa");
	length = 0;
	SenderFlag = 'S';
	ReceiverFlag = 'R';
	senderSocket = receiverSocket = -1;
	serverSocket = GetTCPSocket();
	
	/* Wait for both a sender and a receiver */
	while (senderSocket < 0 || receiverSocket < 0)
	{
		sizeAddress = sizeof(clientAddress);
		memset(&clientAddress, 0, sizeAddress);
		
		/* Accept client connection */
		if ((clientSocket = accept(serverSocket, (struct sockaddr *) &clientAddress, &sizeAddress)) < 0)
			DieWithSystemMessage("accept() failed");
		
		/* Wait for metadata */
		memset(buffer, 0, BufferSize);
		if (recv(clientSocket, buffer, BufferSize, 0) < 0)
			DieWithSystemMessage("recv() failed");
			
		/* Parse metadata */
		if (buffer[0] == SenderFlag && senderSocket < 0)
		{
			senderSocket = clientSocket;
			for (i = 1; buffer[i] && buffer[i] >= '0' && buffer[i] <= '9'; i++);
			number = (char *) malloc((i - 1) * sizeof(char));
			if (!number)
				DieWithSystemMessage("malloc() failed");
			memcpy(number, &buffer[1], i - 1);
			length = atoi(number);

			censoredMessage = (char *) malloc(length * sizeof(char));
			originalMessage = (char *) malloc(length * sizeof(char));
			if (!censoredMessage || !originalMessage)
				DieWithSystemMessage("malloc() failed");
		}
		else if (buffer[0] == ReceiverFlag && receiverSocket < 0)
			receiverSocket = clientSocket;
		else
			if (close(clientSocket) < 0)
				DieWithSystemMessage("close() failed");
	}
	
	/* Receive the message */
	memset(originalMessage, 0, length);
	if (recv(senderSocket, originalMessage, length, 0) < 0)
		DieWithSystemMessage("recv() failed");

	/* Perform censorship */
	memset(censoredMessage, 0, length);
	for (i = 0, j = 0; i < length; i++)
	{
		memcpy(chunk, &originalMessage[i], TabuSize);
		chunk[TabuSize] = 0;
		if (strcmp(chunk, tabu))
			censoredMessage[j++] = originalMessage[i];
		else
			i += (TabuSize - 1);
	}
	
	/* Send censored message to receiver */
	if (send(receiverSocket, censoredMessage, j, 0) < 0)
		DieWithSystemMessage("send() failed");
	
	/* Clean up and close */
	if (close(senderSocket) < 0 || close(receiverSocket) < 0)
		DieWithSystemMessage("close() failed");
	exit(EXIT_SUCCESS);
}
