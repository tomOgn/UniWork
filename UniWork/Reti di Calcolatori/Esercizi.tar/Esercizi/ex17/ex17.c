/* Il server attende 10 connessioni. Per ognuna crea uno specifico thread che la gestisce.
 * Ogni client invia 10 numeri interi positivi. Il thread seleziona il numero piu' grande 
 * e lo invia al thread Main. Il thread Main stabilisce tra tutti il numero piu' grande. */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <pthread.h>
#include <sys/select.h>

#define BufferSize 100
#define MaxPending 10
#define NumThreads 3
#define MaxServers 10
#define NumReads 3

void DieWithSystemMessage(char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

void DieWithUserMessage(char *message)
{
	printf("%s\n", message);
	exit(EXIT_FAILURE);
}
  
void *ThreadHandler(void *parameter)
{
	int *returnValue, clientSocket, count, max, i, j;
	char buf[BufferSize], number[BufferSize];

	clientSocket = *((int*)parameter);
	max = -1;
	for (i = 0; i < NumReads; i++)
	{
		/* Read data from client */
		if ((count = read(clientSocket, buf, BufferSize)) < 0)
			DieWithSystemMessage("read() failed");

		/* Parse integer number */
		memset(number, 0, BufferSize);
		for (j = 0; j < count && buf[j] >= '0' && buf[j] <= '9'; j++)
			number[j] = buf[j];
		if (atoi(number) > max)
			max = atoi(number);
	}

	/* Build return value */
	if (!(returnValue = malloc(sizeof(int))))
		DieWithSystemMessage("malloc() failed");
	*returnValue = max;
	
	/* Clean up and exit */
	free(parameter);
	if (close(clientSocket) < 0)
		DieWithSystemMessage("close() failed");
	pthread_exit(returnValue);
}

int main(int argc, char *argv[])
{
	struct sockaddr_in serverAddress, clientAddress;
	int OptVal, i, serverSocket[MaxServers], clientSocket, *threadParameter, max, count, numServers, countThreads;
	pthread_t vthreads[NumThreads];
	fd_set activeSet, readSet;
	void *returnValue;
	socklen_t clientSize;
	
	OptVal = 1;
	max = -1;
	numServers = (argc - 1) / 2;
	FD_ZERO(&activeSet);
	for (i = 0; i < numServers; i++)
	{
		/* Get a stream socket */
		if ((serverSocket[i] = socket(AF_INET, SOCK_STREAM, 0)) < 0)
			DieWithSystemMessage("socket() failed");

		/* Avoid EADDRINUSE error on bind() */
		if (setsockopt(serverSocket[i], SOL_SOCKET, SO_REUSEADDR, (char *) &OptVal, sizeof(OptVal)) < 0) 
			DieWithSystemMessage("setsockopt() failed");
			
		/* Construct server address */
		memset(&serverAddress, 0, sizeof(serverAddress));
		serverAddress.sin_family = AF_INET;
		serverAddress.sin_addr.s_addr = inet_addr(argv[(i * 2) + 1]);
		serverAddress.sin_port = htons(atoi(argv[(i * 2) + 2]));

		/* Bind socket to address */
		if (bind(serverSocket[i], (struct sockaddr *) &serverAddress, sizeof(serverAddress)) < 0)
			DieWithSystemMessage("bind() failed");
			
		/* Enable incoming connections */
		if (listen(serverSocket[i], MaxPending) < 0)
			DieWithSystemMessage("listen() failed");
		
		/* Add socket to active set of file descriptors */
		FD_SET(serverSocket[i], &activeSet);
		if (serverSocket[i] > max)
			max = serverSocket[i];
	}
	
	countThreads = 0;
	while (countThreads < NumThreads)
	{
		/* Wait for incoming connections in one of the network inferfaces */
		do
		{
			readSet = activeSet;
			count = select(max + 1, &readSet, NULL, NULL, NULL);
		}
		while (count <0 && errno == EINTR);
		if (count < 0)
			DieWithSystemMessage("select() failed");
		
		for (i = 0; i < numServers; i++)
		{
			if (FD_ISSET(serverSocket[i], &readSet)) 
			{ 
				/* Accept client connection */
				clientSize = sizeof(clientAddress);
				clientSocket= accept(serverSocket[i], (struct sockaddr *) &clientAddress, &clientSize);
				
				/* Build thread actual parameter */
				if (!(threadParameter = malloc(sizeof(int))))
					DieWithSystemMessage("malloc() failed");
				*threadParameter = clientSocket;

				/* Spawn client thread */
				if (pthread_create(&vthreads[countThreads], NULL, ThreadHandler, threadParameter))
					DieWithSystemMessage("pthread_create() failed");
				countThreads++;
			}
		}
	}
		
	/* Wait all threads to terminate */
	max = -1;
	for (i = 0; i < NumThreads; i++)
	{
		if (pthread_join(vthreads[i] , (void *) &returnValue))
			DieWithSystemMessage("pthread_create() failed");
		
		/* Update max value */
		if (*((int *) returnValue) > max)
			max = *((int *) returnValue);
		free(returnValue);
	}
	
	/* Printout overal max value */
	printf("Overal Max Number = %d\n", max);
	
	/* Clean up and exit */
	for (i = 0; i < numServers; i++)
		if (close(serverSocket[i]) < 0)
			DieWithSystemMessage("close() failed");
	exit(EXIT_SUCCESS);
}
