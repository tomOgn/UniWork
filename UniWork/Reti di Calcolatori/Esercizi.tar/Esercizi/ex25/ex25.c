/*
 * Il server attende 5 connessioni TCP.
 * Quando tutte e 5 sono state accettate, ai client viene chiesto, in 
 * modo parallelo, di indovinare un numero.
 * Il valore del numero e' il parametro di input del programma server.
 * Se il numero ipotizzato dal client e' maggiore, si risponde con un
 * "<", altrimenti con un ">".
 * Il primo ad indovinare, riceve un messaggio di vittoria, gli altri
 * di sconfitta e il programma termina.
*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>

#define NumThreads 5
#define BufferSize 100
#define MaxPending NumThreads

pthread_mutex_t SynMutex; 
pthread_cond_t SynCond;
int MagicNumber, Winner = 0, SynCount = 0; 

void DieWithSystemMessage(const char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

void ThreadError(const char *message, int clientSocket)
{
	perror(message);
	close(clientSocket);
	pthread_exit(NULL);
}

void SendMessage(int clientSocket, char *message)
{
	int count;
	
	do
		count = send(clientSocket, message, strlen(message) + 1, 0);
	while (count < 0 && errno == EINTR);
	
	if (count < 0)
		ThreadError("send() failed", clientSocket);
}

void *ThreadHandler(void *parameter)
{
	int clientSocket, count, guess, i;
	char buf[BufferSize], numeric[BufferSize];

	/* Barrier mechanism for a fair game */
	pthread_mutex_lock(&SynMutex);
	SynCount++; 
	if (SynCount < NumThreads) 
		pthread_cond_wait(&SynCond, &SynMutex); 
	else
		pthread_cond_broadcast(&SynCond); 
	pthread_mutex_unlock(&SynMutex);

	clientSocket = *((int *) parameter);
	free(parameter);
	
	/* Write introductory message */
	SendMessage(clientSocket, "Try to guess a natural number:\n");
	
	/* Repeat until the client find the number */
	do
	{
		/* Wait the guessing */
		memset(buf, 0, BufferSize);
		do
			count = recv(clientSocket, buf, BufferSize, 0);
		while (count < 0 && errno == EINTR);

		if (count < 0)
			ThreadError("recv() failed", clientSocket);
		else if (count == 0)
		{
			printf("Client has closed the connection.\n");
			close(clientSocket);
			pthread_exit(NULL);
		}
		
		/* Check if we have already a winner */
		pthread_mutex_lock(&SynMutex);
		if (Winner)
		{
			pthread_mutex_unlock(&SynMutex);
			SendMessage(clientSocket, "Sorry, we got a winner, and it's not you :P\n");
			
			/* Clean up and exit */
			close(clientSocket);
			pthread_exit(NULL);
		}
		pthread_mutex_unlock(&SynMutex);
		
		/* Parse the guessing */
		memset(numeric, 0, BufferSize);
		for (i = 0; buf[i] >= '0' && buf[i] <= '9'; i++)
			numeric[i] = buf[i];
		guess = atoi(numeric);
		
		/* If the guessing is wrong, give an hint */
		if (guess > MagicNumber)
			SendMessage(clientSocket, "<\n");
		else if (guess < MagicNumber)
			SendMessage(clientSocket, ">\n");
	}
	while (guess != MagicNumber);
	
	pthread_mutex_lock(&SynMutex);
	Winner = 1;
	pthread_mutex_unlock(&SynMutex);
	
	SendMessage(clientSocket, "You are the WINNER!\n");

	/* Clean up and exit */
	close(clientSocket);
	pthread_exit(NULL);
}

int main(int argc, char *argv[])
{
	pthread_t threads[NumThreads];
	int i, *parameter;
	struct sockaddr_in serverAddress, clientAddress;
	short int serverPort;
	int serverSocket, clientSocket, OptVal;
	unsigned int sizeAddress;

	/* Check number or parameters */
	if (argc != 3)
	{
		printf("The function requires 2 parameters to be passed in.");
		exit(EXIT_FAILURE);
	}
	serverPort = atoi(argv[1]);
	MagicNumber = atoi(argv[2]);
	sizeAddress = sizeof(struct sockaddr_in);
	
	/* Get a stream socket */
	if ((serverSocket = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		DieWithSystemMessage("socket() failed");

	/* Avoid EADDRINUSE error on bind() */
	OptVal = 1;
	if (setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, (char *) &OptVal, sizeof(OptVal)) < 0)
		DieWithSystemMessage("setsockopt() failed");

	/* Construct server address */
	memset(&serverAddress, 0, sizeAddress);
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = htonl(INADDR_ANY);
	serverAddress.sin_port = htons(serverPort);

	/* Bind socket to address */
	if (bind(serverSocket, (struct sockaddr *) &serverAddress, sizeAddress) < 0)
		DieWithSystemMessage("bind() failed");

	/* Enable incoming connections */
	if (listen(serverSocket, MaxPending) < 0)
		DieWithSystemMessage("listen() failed");
	
	/* Wait for 5 connections */
	for (i = 0; i < NumThreads; i++)
	{
		/* Accept new connection */
		do
		{
			sizeAddress = sizeof(clientAddress);
			memset(&clientAddress, 0, sizeAddress);
			clientSocket = accept(serverSocket, (struct sockaddr *) &clientAddress, &sizeAddress);
		}
		while (clientSocket < 0 && errno == EINTR);
		if (clientSocket < 0)
			DieWithSystemMessage("accept() failed");

		/* Build thread parameter */
		if (!(parameter = malloc(sizeof(int))))
			DieWithSystemMessage("malloc() failed");
		*parameter = clientSocket;

		/* Spawn client thread */
		if (pthread_create(&threads[i], NULL, ThreadHandler, parameter))
			DieWithSystemMessage("pthread_create() failed");
	}
	
	/* Wait for all threads to terminate */
	for (i = 0; i < NumThreads; i++)
	{
		int *ptr;
		if (pthread_join(threads[i], (void *) &ptr ))
			DieWithSystemMessage("pthread_join() failed");
		free(ptr);
	}
	
	pthread_exit(NULL);
}
