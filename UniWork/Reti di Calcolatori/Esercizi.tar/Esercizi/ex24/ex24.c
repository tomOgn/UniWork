/*
 * Il server gestisce una chat ennesima. Protocollo TCP.
 * Ogni messaggio inviato da un client viene inviato a tutti gli altri,
 * con l'aggiunta di del pattern [socket] che identifica il mittente del
 * messaggio.
*/

#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

typedef struct sockaddr SA;
#define BufferSize 1000
#define ServerPort 5000
#define MaxPending 100

void DieWithSystemMessage(const char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

int main (int argc, char *argv[])
{
	int numClients, i, j, maxIndex, maxFD, serverSocket, clientSocket, count, clientSockets[FD_SETSIZE];
	ssize_t n;
	fd_set Rset;
	socklen_t sizeAddress;
	struct sockaddr_in clientAddress, serverAddress;
	char buf[BufferSize], message[BufferSize];
	
	sizeAddress = sizeof(serverAddress);
	
	/* Create TCP socket */
	if ((serverSocket = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		DieWithSystemMessage("socket() failed");

	/* Construct server address */
	memset(&serverAddress, 0, sizeAddress);
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = htonl(INADDR_ANY);
	serverAddress.sin_port = htons(ServerPort);
	
	/* Bind socket to address */
	if (bind(serverSocket, (SA *) &serverAddress, sizeAddress) < 0) 
		DieWithSystemMessage("bind() failed");
		
	/* Enable incoming connections */
	if (listen(serverSocket, MaxPending) < 0)
		DieWithSystemMessage("listen() failed");

	/* Initialize variables */
	numClients = 0;
	maxIndex = -1;
	for (i = 0; i < FD_SETSIZE; i++)
		clientSockets[i] = -1;
	
	/* Chat manager */
	while (1)
	{
		do 
		{
			FD_ZERO(&Rset);
			FD_SET(serverSocket, &Rset);
			maxFD = serverSocket;
			for (i = 0; i <= maxIndex; i++)
			{
				if (clientSockets[i] >= 0)
				{
					FD_SET(clientSockets[i], &Rset);
					
					if (maxFD < clientSockets[i]) 
						maxFD = clientSockets[i];
				}
			}
			count = select(maxFD + 1, &Rset, NULL, NULL, NULL);
		}
		while (count < 0 && errno == EINTR);
		if (count < 0)
			DieWithSystemMessage("select() failed");

		/* New client connection */
		if (FD_ISSET(serverSocket, &Rset) && numClients < FD_SETSIZE)
		{ 
			/* Accept connection */
			sizeAddress = sizeof(clientAddress);
			if ((clientSocket = accept( serverSocket, (SA *) &clientAddress, &sizeAddress)) < 0) 
				DieWithSystemMessage("accept() failed");
			
			numClients++;
			for (i = 0; clientSockets[i] >= 0; i++);
			clientSockets[i] = clientSocket;
			
			if (i > maxIndex)
				maxIndex = i;
			if (--count <= 0)
				continue;
		}
		
		/* Check all clients for data */
		for (i = 0; i <= maxIndex && count > 0; i++)  
		{
			if ((clientSocket = clientSockets[i]) < 0)
				continue;

			/* Read Set: data to be received */
			if (FD_ISSET(clientSocket, &Rset))
			{
				memset(buf, 0, BufferSize);
				do
					n = recv(clientSocket, buf, BufferSize, 0);
				while (n < 0 && errno == EINTR);
				
				/* Connection closed or error */
				if (n == 0)
				{
					close(clientSocket);
					clientSockets[i] = -1;
				}
				else
				{
					/* Parse message */
					printf("1 %s\n", buf);
					for (j = 0; j < n && buf[j] != '\n'; j++);
					buf[j] = 0;
					printf("2 %s\n", buf);
					memset(message, 0, BufferSize);
					sprintf(message, "[%d] %s\n", clientSockets[i], buf);
					printf("3 %s\n", buf);
					/* Send to everybody else */
					for (j = 0; j <= maxIndex; j++)
					{
						if (clientSockets[j] != serverSocket && j != i)
						{
							do
								n = send(clientSockets[j], message, strlen(message) + 1, MSG_NOSIGNAL | MSG_DONTWAIT);
							while (n < 0 && errno == EINTR);
							
							/* Connection error */
							if (n < 0)
							{
								printf("Error detected from socket %d\n", clientSocket);
								close(clientSockets[j]);
								clientSockets[j] = -1;
							} 
						}
					}
				}
				count--;
			}
		}
	}
}
