#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/select.h>

#define MessageSize 1000000
#define Chunk 30000
#define MetadataSize 10
#define DataSize (Chunk - MetadataSize)
#define HandshakeSize 4

int PortA = 60000, PortB = 8000, PortC = 60001;
char *StringA = "127.0.0.1", *StringB = "127.0.0.2", *StringC = "127.0.0.3";

void DieWithSystemMessage(const char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

void DieWithUserMessage(const char *message)
{
	printf("%s\n", message);
	exit(EXIT_FAILURE);
}

int CreateUDPSocket(char *sourceString, int sourcePort, char *destinationString, int destinationPort)
{
	unsigned int sock, value, sizeAddress;
	struct sockaddr_in sourceAddress, destinationAddress;
	
	sizeAddress = sizeof(struct sockaddr_in);
	value = 1;
	
	/* Get a datagram socket */
	if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
		DieWithSystemMessage("socket() failed");

	/* Avoid EADDRINUSE error on bind() */ 
	if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char *) &value, sizeof(value)) < 0)
		DieWithSystemMessage("setsockopt() failed");

	/* Construct local address */
	memset(&sourceAddress, 0, sizeAddress);
	sourceAddress.sin_family = AF_INET;
	sourceAddress.sin_addr.s_addr = inet_addr(sourceString);
	sourceAddress.sin_port = htons(sourcePort);

	/* Bind socket to address */
	if (bind(sock, (struct sockaddr *) &sourceAddress, sizeAddress) < 0)
		DieWithSystemMessage("bind() failed");
		
	if (destinationString)
	{
		/* Construct destination address */
		memset(&destinationAddress, 0, sizeAddress);
		destinationAddress.sin_family = AF_INET;
		destinationAddress.sin_addr.s_addr = inet_addr(destinationString);
		destinationAddress.sin_port = htons(destinationPort);
		
		/* Connect to destination */
		if (connect(sock, (struct sockaddr *) &destinationAddress, sizeAddress) < 0) 
			DieWithSystemMessage("connect() failed");
	}

	return sock;
}

int main(int argc, char *argv[])
{
	int socketA, socketB, max, ready, readyA, readyB;
	char *metadata, *message, *handshake;
	fd_set Rset, fullSet;
	
	/* Check number of parameters */
	if (argc != 1)
		DieWithUserMessage("Wrong number of parameters");

	handshake = (char *) malloc(sizeof(char) * HandshakeSize);
	metadata = (char *) malloc(sizeof(char) * MetadataSize);
	message = (char *) malloc(sizeof(char) * Chunk);
	if (!metadata || !message || !handshake)
		DieWithSystemMessage("malloc() failed");

	socketA = CreateUDPSocket(StringC, PortC, StringA, PortA);
	socketB = CreateUDPSocket(StringC, PortC, StringB, PortB);
	
	/* Rendez-vous mechanism */
	max = (socketA > socketB)? socketA: socketB;
	FD_ZERO(&fullSet);
	FD_SET(socketA, &fullSet);
	FD_SET(socketB, &fullSet);
	readyA = readyB = 0;
	do
	{
		do
		{
			Rset = fullSet;
			ready = select(max + 1, &Rset, NULL, NULL, NULL);
		}
		while (ready < 0 && errno == EINTR);
		if (ready < 0)
			DieWithSystemMessage("select() failed");
			
		if (FD_ISSET(socketA, &Rset))
		{
			/* Receive SYN */
			memset(handshake, 0, HandshakeSize);
			if (recv(socketA, handshake, HandshakeSize, 0) < 0)
				DieWithSystemMessage("recv() failed");

			/* Check if it is SYN */
			if (!strcmp(handshake, "SYN"))
				readyA = 1;
		}
		
		if (FD_ISSET(socketB, &Rset))
		{
			/* Receive SYN */
			memset(handshake, 0, HandshakeSize);
			if (recv(socketB, handshake, HandshakeSize, 0) < 0)
				DieWithSystemMessage("recv() failed");

			/* Check if it is SYN */
			if (!strcmp(handshake, "SYN"))
				readyB = 1;
		}
	}
	while (!readyA || !readyB);
	
	/* Send ACK */
	memset(handshake, 0, HandshakeSize);
	strcpy(handshake, "ACK");
	if (write(socketA, handshake, HandshakeSize) < 0)
		DieWithSystemMessage("write() failed");
	if (write(socketB, handshake, HandshakeSize) < 0)
		DieWithSystemMessage("write() failed");
	free(handshake);
	
	FD_ZERO(&fullSet);
	FD_SET(socketA, &fullSet);
	FD_SET(socketB, &fullSet);
	max = (socketA > socketB)? socketA: socketB;
	while (1)
	{
		do
		{
			Rset = fullSet;
			ready = select(max + 1, &Rset, NULL, NULL, NULL);
		}
		while (ready < 0 && errno == EINTR);
		if (ready < 0)
			DieWithSystemMessage("select() failed");
		
		if (FD_ISSET(socketA, &Rset))
		{
			/* Receive chunk */
			memset(message, 0, Chunk);
			if (read(socketA, message, Chunk) < 0)
				DieWithSystemMessage("read() failed");

			/* Check if it is the end of message */
			if (!message[0])
				break;

			/* Re-transmit chunk */
			if (write(socketB, message, Chunk) < 0)
				DieWithSystemMessage("write() failed");
		}
		if (FD_ISSET(socketB, &Rset))
		{
			/* Receive chunk */
			memset(metadata, 0, MetadataSize);
			if (read(socketB, metadata, MetadataSize) < 0)
				DieWithSystemMessage("read() failed");

			/* Re-transmit chunk */
			if (write(socketA, metadata, MetadataSize) < 0)
				DieWithSystemMessage("write() failed");
		}
	}
	
	/* Clean up and exit */
	if (close(socketA) < 0 || close(socketB) < 0)
		DieWithSystemMessage("close() failed");
	exit(EXIT_SUCCESS);
}
