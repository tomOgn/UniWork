#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/select.h>

#define MessageSize 1000000
#define Chunk 30000
#define MetadataSize 10
#define DataSize (Chunk - MetadataSize)
#define HandshakeSize 4

char *Buffer;
int PortA = 60000, PortB = 8000, PortC = 60001;
char *StringA = "127.0.0.1", *StringB = "127.0.0.2", *StringC = "127.0.0.3";

void DieWithSystemMessage(const char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

void DieWithUserMessage(const char *message)
{
	printf("%s\n", message);
	exit(EXIT_FAILURE);
}

int CreateUDPSocket(char *sourceString, int sourcePort, char *destinationString, int destinationPort)
{
	unsigned int sock, value, sizeAddress;
	struct sockaddr_in sourceAddress, destinationAddress;
	
	sizeAddress = sizeof(struct sockaddr_in);
	value = 1;
	
	/* Get a datagram socket */
	if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
		DieWithSystemMessage("socket() failed");

	/* Avoid EADDRINUSE error on bind() */ 
	if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char *) &value, sizeof(value)) < 0)
		DieWithSystemMessage("setsockopt() failed");

	/* Construct local address */
	memset(&sourceAddress, 0, sizeAddress);
	sourceAddress.sin_family = AF_INET;
	sourceAddress.sin_addr.s_addr = inet_addr(sourceString);
	sourceAddress.sin_port = htons(sourcePort);

	/* Bind socket to address */
	if (bind(sock, (struct sockaddr *) &sourceAddress, sizeAddress) < 0)
		DieWithSystemMessage("bind() failed");
		
	if (destinationString)
	{
		/* Construct destination address */
		memset(&destinationAddress, 0, sizeAddress);
		destinationAddress.sin_family = AF_INET;
		destinationAddress.sin_addr.s_addr = inet_addr(destinationString);
		destinationAddress.sin_port = htons(destinationPort);
		
		/* Connect to destination */
		if (connect(sock, (struct sockaddr *) &destinationAddress, sizeAddress) < 0) 
			DieWithSystemMessage("connect() failed");
	}

	return sock;
}

int main(int argc, char *argv[])
{
	unsigned int socketC, count, i, chunkNum, expectedNum, ready;
	char *message, *metadata, *handshake;
	fd_set Rset;
	struct timeval timeout;
	timeout.tv_sec = 0;
	timeout.tv_usec = 100000;
	
	/* Check number of parameters */
	if (argc != 1)
		DieWithUserMessage("Wrong number of parameters");

	/* Initialize variables */
	Buffer = (char *) malloc(sizeof(char) * MessageSize);
	message = (char *) malloc(sizeof(char) * Chunk);
	metadata = (char *) malloc(sizeof(char) * MetadataSize);
	if (!Buffer || !message || !metadata)
		DieWithSystemMessage("malloc() failed");
	memset(Buffer, 0, MessageSize);
	
	/* Get datagram sockets */
	socketC = CreateUDPSocket(StringB, PortB, StringC, PortC);
	
	/* Rendez-vous mechanism */
	handshake = (char *) malloc(sizeof(char) * HandshakeSize);
	do
	{
		/* Send SYN */
		memset(handshake, 0, HandshakeSize);
		strcpy(handshake, "SYN");
		if (send(socketC, handshake, HandshakeSize, 0) < 0)
			DieWithSystemMessage("send() failed");
			
		/* Wait ACK */
		do
		{
			FD_ZERO(&Rset);
			FD_SET(socketC, &Rset);
			ready = select(socketC + 1, &Rset, NULL, NULL, &timeout);
		}
		while (ready < 0 && errno == EINTR);
		if (ready < 0)
			DieWithSystemMessage("select() failed");
		
		memset(handshake, 0, HandshakeSize);
		/* Receive ACK */
		if (ready > 0)
			if (recv(socketC, handshake, HandshakeSize, 0) < 0)
				DieWithSystemMessage("recv() failed");
	}
	while (strcmp(handshake, "ACK"));
	free(handshake);
	
	/* Receive the message */
	expectedNum = 0;
	for (count = 0; count < MessageSize; count += DataSize)
	{
		do
		{
			/* Receive chunk */
			memset(message, 0, Chunk);
			if (read(socketC, message, Chunk) < 0)
				DieWithSystemMessage("read() failed");
			
			/* Extract metadata */
			for (i = 0; i < MetadataSize; i++)
				metadata[i] = message[i];
			chunkNum = atoi(metadata);
		}
		/* Repeat until the expected chunk is obtained */
		while (expectedNum != chunkNum);
		
		/* Send back the chunk number */
		if (write(socketC, metadata, MetadataSize) < 0)
			DieWithSystemMessage("write() failed");

		/* Extract data */
		sprintf(&Buffer[count], "%s", &message[MetadataSize - 1]);
		
		expectedNum++;
	}
	
	printf("Received %d bytes\n", strlen(Buffer));
	
	/* Clean up and exit */
	if (close(socketC) < 0)
		DieWithSystemMessage("close() failed");
	exit(EXIT_SUCCESS);
}
