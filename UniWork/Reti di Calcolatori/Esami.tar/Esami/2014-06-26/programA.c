#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/select.h>

#define MessageSize 1000000
#define Chunk 30000
#define MetadataSize 10
#define DataSize (Chunk - MetadataSize)
#define HandshakeSize 4

char *Source;
int PortA = 60000, PortB = 8000, PortC = 60001;
char *StringA = "127.0.0.1", *StringB = "127.0.0.2", *StringC = "127.0.0.3";

void DieWithSystemMessage(const char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

void DieWithUserMessage(const char *message)
{
	printf("%s\n", message);
	exit(EXIT_FAILURE);
}

int CreateUDPSocket(char *sourceString, int sourcePort, char *destinationString, int destinationPort)
{
	unsigned int sock, value, sizeAddress;
	struct sockaddr_in sourceAddress, destinationAddress;
	
	sizeAddress = sizeof(struct sockaddr_in);
	value = 1;
	
	/* Get a datagram socket */
	if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
		DieWithSystemMessage("socket() failed");

	/* Avoid EADDRINUSE error on bind() */ 
	if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char *) &value, sizeof(value)) < 0)
		DieWithSystemMessage("setsockopt() failed");

	/* Construct local address */
	memset(&sourceAddress, 0, sizeAddress);
	sourceAddress.sin_family = AF_INET;
	sourceAddress.sin_addr.s_addr = inet_addr(sourceString);
	sourceAddress.sin_port = htons(sourcePort);

	/* Bind socket to address */
	if (bind(sock, (struct sockaddr *) &sourceAddress, sizeAddress) < 0)
		DieWithSystemMessage("bind() failed");
		
	if (destinationString)
	{
		/* Construct destination address */
		memset(&destinationAddress, 0, sizeAddress);
		destinationAddress.sin_family = AF_INET;
		destinationAddress.sin_addr.s_addr = inet_addr(destinationString);
		destinationAddress.sin_port = htons(destinationPort);
		
		/* Connect to destination */
		if (connect(sock, (struct sockaddr *) &destinationAddress, sizeAddress) < 0) 
			DieWithSystemMessage("connect() failed");
	}

	return sock;
}

int main(int argc, char *argv[])
{
	unsigned int socketC, count, i, chunkNum, confirmedNum, ready, chunkSize;
	char *message, *metadata, *buf, *handshake;
	struct timeval timeout;
	fd_set Rset;
	
	/* Check number of parameters */
	if (argc != 1)
		DieWithUserMessage("Wrong number of parameters");

	/* Initialize variables */
	Source = (char *) malloc(sizeof(char) * MessageSize);
	message = (char *) malloc(sizeof(char) * Chunk);
	metadata = (char *) malloc(sizeof(char) * MetadataSize);
	buf = (char *) malloc(sizeof(char) * MetadataSize);
	if (!Source || !message || !metadata || !buf)
		DieWithSystemMessage("malloc() failed");
	memset(Source, 'a', MessageSize);
	timeout.tv_sec = 0;
	timeout.tv_usec = 100000;
	
	/* Get sockets */
	socketC = CreateUDPSocket(StringA, PortA, StringC, PortC);
	
	/* Rendez-vous mechanism */
	handshake = (char *) malloc(sizeof(char) * HandshakeSize);
	do
	{
		/* Send SYN */
		memset(handshake, 0, HandshakeSize);
		strcpy(handshake, "SYN");
		if (send(socketC, handshake, HandshakeSize, 0) < 0)
			DieWithSystemMessage("send() failed");
			
		/* Wait ACK */
		do
		{
			FD_ZERO(&Rset);
			FD_SET(socketC, &Rset);
			ready = select(socketC + 1, &Rset, NULL, NULL, &timeout);
		}
		while (ready < 0 && errno == EINTR);
		if (ready < 0)
			DieWithSystemMessage("select() failed");
		
		memset(handshake, 0, HandshakeSize);
		/* Receive ACK */
		if (ready > 0)
			if (recv(socketC, handshake, HandshakeSize, 0) < 0)
				DieWithSystemMessage("recv() failed");
	}
	while (strcmp(handshake, "ACK"));
	free(handshake);
	
	/* Send the message */
	chunkNum = 0;
	for (count = 0; count < MessageSize; count += DataSize)
	{
		chunkSize = (count + DataSize <= MessageSize)? DataSize: MessageSize - count;
		memset(message, 0, Chunk);
		
		/* Add metadata */
		memset(metadata, 0, MetadataSize);
		sprintf(metadata, "%d", chunkNum);
		for (i = 0; metadata[i]; i++)
			message[i] = metadata[i];
			
		/* Add data */
		for (i = 0; i < chunkSize; i++)
			message[i + MetadataSize - 1] = Source[i + count];
			
		do
		{
			/* Send the chunk */
			if (send(socketC, message, Chunk, 0) < 0)
				DieWithSystemMessage("send() failed");
			
			/* Wait for confirmation */
			do
			{
				FD_ZERO(&Rset);
				FD_SET(socketC, &Rset);
				ready = select(socketC + 1, &Rset, NULL, NULL, &timeout);
			}
			while (ready < 0 && errno == EINTR);
			if (ready < 0)
				DieWithSystemMessage("select() failed");
				
			if (ready > 0)
			{
				fflush(stdout);
				memset(buf, 0, MetadataSize);
				if (recv(socketC, buf, MetadataSize, 0) < 0)
					DieWithSystemMessage("recv() failed");
					
				confirmedNum = atoi(buf);
			}
		}
		/* Repeat until the chunk has been received */
		while (!ready || confirmedNum != chunkNum);
		
		chunkNum++;
	}

	/* Send an empty message meaning the operation is finished */
	memset(message, 0, Chunk);
	if (write(socketC, message, Chunk) < 0)
		DieWithSystemMessage("write() failed");
	
	/* Clean up and exit */
	if (close(socketC) < 0)
		DieWithSystemMessage("close() failed");
	exit(EXIT_SUCCESS);
}
