/*
La funzione riceve un numero pari di argomenti <IP Address, Port Number>
per un massimo di 5 connessioni.
Si tenta di connettersi a tutte parallelamente. Non appena una ha successo,
le altre vengono chiuse. Si spedisce un messaggio e si attenda la chiusura.
*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/time.h>

#define MaxThreads 5
#define BufferSize 100
#define False 0
#define True 1

pthread_mutex_t MutexConnectionEstablished; 
int ConnectionEstablished = False;
	
typedef struct
{
	char RemoteAddress[100];
	short int RemotePort;
	int ServerSocket;
} Server;

void DieWithSystemMessage(char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

void DieWithUserMessage(char *message)
{
	printf("%s\n", message);
	exit(EXIT_FAILURE);
}

void *ThreadHandler(void *parameter)
{
	int count, offset, length, flags;
	char buffer[BufferSize], *message;
	Server *server;
	struct sockaddr_in serverAddress;
	fd_set readSet, writeSet;
	struct timeval timeout; 
	
	/* Initialize variables */
	timeout.tv_sec = 0;
	timeout.tv_usec = 200000;
	message = "Ciao";
	server = (Server *) parameter;
		
	/* Set non-blocking socket */
	if ((flags = fcntl(server->ServerSocket, F_GETFL, 0)) < 0)
		DieWithSystemMessage("fcntl(F_GETFL) failed");
	flags |= O_NONBLOCK; 
	if (fcntl(server->ServerSocket, F_SETFL, flags) < 0)
		DieWithSystemMessage("fcntl(F_SETFL) failed");
		
	/* Construct server address */
	memset(&serverAddress, 0, sizeof(serverAddress));
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = inet_addr(server->RemoteAddress);
	serverAddress.sin_port = htons(server->RemotePort);
	
	/* Non-blocking connection request */
	count = connect(server->ServerSocket, (struct sockaddr*) &serverAddress, sizeof(serverAddress));
	if (count < 0)
	{
		if (errno != EINPROGRESS)
			DieWithSystemMessage("connect() failed");
		
		printf("Connection failed by now\n");
		/* Wait for connection until timeout expires */
		do
		{
			FD_ZERO(&readSet);
			FD_SET(server->ServerSocket, &readSet);
			writeSet = readSet;
			count = select(server->ServerSocket + 1, &readSet, &writeSet, NULL, &timeout);
			if (count < 0)
				DieWithSystemMessage("select() failed");
			if (count == 0)
			{
				/* Check if a connection has already been established */
				pthread_mutex_lock(&MutexConnectionEstablished);
				if (ConnectionEstablished)
				{
					pthread_mutex_unlock(&MutexConnectionEstablished);
					free(parameter);
					close(server->ServerSocket);
					printf("[Thread ID: %d] My assigned server does not answer yet. Anyway I terminate since another connection " 
						"has already been established\n", (int) pthread_self());
					pthread_exit(NULL);
				}
				pthread_mutex_unlock(&MutexConnectionEstablished);					
			}
			else if (!FD_ISSET(server->ServerSocket, &readSet) && !FD_ISSET(server->ServerSocket, &writeSet))
				DieWithUserMessage("select(): not working socket");
		}
		while (count == 0);
		
		/* Check connection */
		count = connect(server->ServerSocket, (struct sockaddr *) &serverAddress, sizeof(serverAddress));
		if (count < 0 && errno != EISCONN) 
			DieWithUserMessage("connect(): connection did not succeed");
	}
	
	/* Check if a connection has already been established */
	pthread_mutex_lock(&MutexConnectionEstablished);
	if (ConnectionEstablished)
	{
		pthread_mutex_unlock(&MutexConnectionEstablished);
		free(parameter);
		close(server->ServerSocket);
		printf("[Thread ID: %d] My connection request has been accepted, but it is too late. " 
			"Another one has already been established. Therefore I terminate.\n", (int) pthread_self());
		pthread_exit(NULL);
	}
	ConnectionEstablished = True;
	pthread_mutex_unlock(&MutexConnectionEstablished);
	
	/* Set blocking socket */
	if ((flags = fcntl(server->ServerSocket, F_GETFL, 0)) < 0)
		DieWithSystemMessage("fcntl(F_GETFL) failed");
	flags &= (~O_NONBLOCK); 
	if (fcntl(server->ServerSocket, F_SETFL, flags) < 0)
		DieWithSystemMessage("fcntl(F_SETFL) failed");

	/* Send message to server */
	length = strlen(message) + 1;
	offset = 0;
	while ((count = write(server->ServerSocket, &(message[offset]), length - offset)) > 0)
		offset += count;
	if (count < 0)
		DieWithSystemMessage("write() failed");

	/* Wait until server disconnects */
	do
		count = read(server->ServerSocket, buffer, BufferSize);
	while (count > 0 || (count < 0 && errno == EINTR));
	if (count < 0)
		DieWithSystemMessage("read() failed");

	/* Clean up and exit */
	free(parameter);
	close(server->ServerSocket);
	pthread_exit(NULL);
}

int main(int argc, char *argv[])
{
	struct sockaddr_in localAddress; 
	Server *server;
	int numConnections, i, OptVal;
	pthread_t threads[MaxThreads];

	pthread_mutex_init(&MutexConnectionEstablished, NULL);
	numConnections = (argc - 1) / 2;
	
	/* Check number of parameters */
	if ((argc - 1) % 2 != 0 || numConnections > 10)
		DieWithUserMessage("Wrong number of parameters.");

	/* Construct local address */
	memset(&localAddress, 0, sizeof(localAddress));
	localAddress.sin_family = AF_INET;
	localAddress.sin_addr.s_addr = htonl(INADDR_ANY);
	localAddress.sin_port = htons(0);

	/* Try every viable connections */
	for (i = 0; i < numConnections; i++)
	{
		/* Build thread parameter */
		if (!(server = malloc(sizeof(Server))))
			DieWithSystemMessage("malloc() failed");
		
		/* Get a datagram socket */
		if ((server->ServerSocket = socket(AF_INET, SOCK_STREAM, 0)) < 0)
			DieWithSystemMessage("socket() failed");

		/* Avoid EADDRINUSE error on bind() */
		OptVal = 1;
		if (setsockopt(server->ServerSocket, SOL_SOCKET, SO_REUSEADDR, (char *) &OptVal, sizeof(OptVal)) < 0)
			DieWithSystemMessage("setsockopt() failed");
			
		/* Bind socket to address */
		if (bind(server->ServerSocket, (struct sockaddr*) &localAddress, sizeof(localAddress)) < 0)
			DieWithSystemMessage("bind() failed");
		
		strncpy(server->RemoteAddress, argv[(i * 2) + 1], 99);
		server->RemotePort = atoi(argv[(i * 2) + 2]);

		/* Spawn thread */
		if (pthread_create(&threads[i], NULL, ThreadHandler, server))
			DieWithSystemMessage("pthread_create() failed");
	}
	
	/* Wait for every threads to terminate */
	for (i = 0;i < numConnections; i++)
		if (pthread_join(threads[i], NULL))
			DieWithSystemMessage("pthread_join() failed");

	/* Clean up and exit */
	pthread_mutex_destroy(&MutexConnectionEstablished);
	exit(EXIT_SUCCESS);
}
