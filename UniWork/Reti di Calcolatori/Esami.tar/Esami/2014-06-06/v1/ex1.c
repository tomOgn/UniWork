/*
 * Il client prova a connettersi ad un massimo di 10 server.
 * Il client riceve in input un massimo di 5 coppie (address, port number)
 * relative ad ogni server.
 * Al primo che accetta la connessione, il client invia un messaggio e 
 * termina, terminando tutte le altre connessioni o tentativi di connessione.
 * I tentativi di connessione devono essere paralleli e minimizzare il 
 * busy waiting.
*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>

#define BufferSize 100

typedef struct
{
	struct sockaddr_in Address;
	int Socket;
} Server;

void DieWithSystemMessage(const char *message)
{
	perror(message);
	exit(EXIT_FAILURE);
}

void DieWithUserMessage(const char *message)
{
	printf("%s\n", message);
	exit(EXIT_FAILURE);
}

void SendMessage(int socket, char *message)
{
	int count;
	
	do
		count = send(socket, message, strlen(message) + 1, 0);
	while (count < 0 && errno == EINTR);
	
	if (count < 0)
		DieWithSystemMessage("send() failed");
}

void SetNonBlocking(int socket)
{
	int flags;
	
	if ((flags = fcntl(socket, F_GETFL, 0)) < 0) 
		DieWithSystemMessage("fcntl(F_GETFL) failed");
		
	flags |= O_NONBLOCK;
	if (fcntl(socket, F_SETFL, flags) < 0) 
		DieWithSystemMessage("fcntl(F_SETFL) failed");
}

void SetBlocking(int socket)
{
	int flags;
	
	if ((flags = fcntl(socket, F_GETFL, 0)) < 0) 
		DieWithSystemMessage("fcntl(F_GETFL) failed");
		
	flags &= (~O_NONBLOCK);
	if (fcntl(socket, F_SETFL, flags) < 0) 
		DieWithSystemMessage("fcntl(F_SETFL) failed");
}

int main(int argc, char *argv[])
{
	struct sockaddr_in serverAddress, clientAddress;
	int clientSocket, value, count, numServers, maxFD, connected, i, j;
	Server *servers;
	unsigned int sizeAddress;
	fd_set readSet, writeSet;
	
	/* Check number of parameters */
	count = argc - 1;
	if (count % 2 != 0 || count / 2 > 5 || count == 0)
	{
		printf("Wrong number of parameters.\n");
		exit(EXIT_FAILURE);
	}
	
	/* Initialize variables */
	connected = 0;
	sizeAddress = sizeof(struct sockaddr_in);
	FD_ZERO(&readSet);
	maxFD = -1;
	numServers = count / 2;
	servers = (Server *) malloc(numServers * sizeof(Server));
	if (!servers)
		DieWithSystemMessage("malloc() failed");

	/* Try every server until one accepts the connection */
	for (i = 0; i < numServers; i++)
	{
		/* Get a datagram socket */
		if ((clientSocket = socket(AF_INET, SOCK_STREAM, 0)) < 0)
			DieWithSystemMessage("socket() failed");
		
		/* Avoid EADDRINUSE error on bind() */
		value = 1;
		if (setsockopt(clientSocket, SOL_SOCKET, SO_REUSEADDR, (char *) &value, sizeof(value)) < 0)
			DieWithSystemMessage("socket() failed");
		
		/* Construct client address */
		memset(&clientAddress, 0, sizeAddress);
		clientAddress.sin_family = AF_INET;
		clientAddress.sin_addr.s_addr = htonl(INADDR_ANY);
		clientAddress.sin_port = htons(0);
		
		/* Bind socket to address */
		if (bind(clientSocket, (struct sockaddr *) &clientAddress, sizeAddress) < 0)
			DieWithSystemMessage("bind() failed");
		
		/* Set non-blocking connection */
		SetNonBlocking(clientSocket);
		
		/* Construct server address */
		memset(&serverAddress, 0, sizeAddress);
		serverAddress.sin_family = AF_INET;
		serverAddress.sin_addr.s_addr = inet_addr(argv[(i * 2) + 1]);
		serverAddress.sin_port = htons(atoi(argv[(i * 2) + 2]));
		
		/* Save connection info */
		servers[i].Address = serverAddress;
		servers[i].Socket = clientSocket;
		
		/* Connection request */
		if (connect(clientSocket, (struct sockaddr *) &serverAddress, sizeAddress) < 0)
		{
			/* Connection failed */
			if (errno != EINPROGRESS)
				DieWithSystemMessage("connect() failed");

			/* Add socket to the set of file descriptors */
			FD_SET(clientSocket, &readSet);
			if (maxFD < clientSocket)
				maxFD = clientSocket;
		}
		else
		{
			/* Connection succeded */
			connected = 1;
			break;
		}
	}

	/* So far no successful connection */
	if (!connected)
	{
		do
		{
			writeSet = readSet;
			count = select(maxFD + 1, &readSet, &writeSet, NULL, NULL);
		}
		while (count < 0 && errno == EINTR);
		if (count < 0)
			DieWithSystemMessage("select() failed");
		
		/* Find active connection */
		for (i = 0; i < numServers; i++)
		{
			clientSocket = servers[i].Socket;
			if (FD_ISSET(clientSocket, &readSet) || FD_ISSET(clientSocket, &writeSet))
			{
				/* Check if connection is truly effective */
				count = connect(clientSocket, (struct sockaddr *) &servers[i].Address, sizeAddress);
				if (count < 0 && errno != EISCONN) 
					DieWithUserMessage("connect(): connection did not succeed");
				printf("count = %d\n", count);
				break;
			}
		}
	}
	
	/* Close all other sockets */
	for (j = 0; j < i; j++)
		close(servers[j].Socket);
	for (j = i + 1; j < numServers; j++)
		close(servers[j].Socket);
	
	/* Set blocking connect */
	SetBlocking(clientSocket);
	
	/* Send data */
	SendMessage(clientSocket, "Hello!");

	/* Clean up and exit */
	close(clientSocket);
	exit(EXIT_SUCCESS);
}
