// foo(x, y)
int global = -1;

csEnter:
	int local;
	do
	{
		local = global;
		foo(local, global);
	}
	while (local > 0);

csExit:
	global = -1;

// bar(x, y)
float global = 0.0;

csEnter:
	float local;
	do
	{
		bar(local, global);
	} while (local > 0);

csExit:
	global = 0.0;