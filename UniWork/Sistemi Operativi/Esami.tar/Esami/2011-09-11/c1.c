monitor seq
{
	Queue order;
	waiting = {} // Python-like dictionary

	procedure entry void enter()
	{
		order.enqueue(getpid());
	}

	procedure entry void exit()
	{
		pid_t actual = getpid();
		pid_t expected = order.top();
		if (actual != expected)
		{
			if (waiting[expected])
				waiting[expected].signal();
			waiting.get(actual, condition()).wait();
			waiting.pop(actual);
		}
		order.dequeue();
	}
}