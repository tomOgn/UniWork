// f(x, y)
/* Non impiegabile, in quanto non determina un passaggio di informazioni
   tra la variabile globale e quella locale, caratteristica fondamentale
   di un meccanismo Test&Set. */

// g(x, y)
int global = 1;

csEnter:
	int local;
	do
	{
		local = 0;
		g(local, global);
	}
	while (local == 0);

csExit:
	global = 1;