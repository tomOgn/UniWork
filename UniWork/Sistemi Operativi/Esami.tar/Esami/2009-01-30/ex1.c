monitor sbb
{
	char buffer[MAX];
	int last, end;
	
	last = 0;
	end = -1;
	
	enqueue(char *s)
	{
		if (strlen(s) >= MAX)
			return -1;
		
		int i = 0;
		while (end + i + 1 < MAX && i <= strlen(s))
		{
			buffer[end + i + 1] = s[i];
			i++;
		}
		
		last = end + 1;
		end += i;
	}
	
	dequeue(char *buf, len l)
	{
		if (l < end - last + 1) return -1;

		for (i = last; i <= end; i++)
			buf[i - last] = buffer[i];
			
		end = last - 1;
		for (i = last - 1; i > 0 && buffer[i - 1]; i--);
		last = i;
			
		return end - last + 1;
	}
}