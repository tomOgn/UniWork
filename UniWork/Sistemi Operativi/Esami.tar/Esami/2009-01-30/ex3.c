ssend(msg, dst)
{
	ssendx(msg, dst);
}

srecvx()
{
	
}