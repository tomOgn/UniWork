monitor reqq
{
	condition applicant, handler;
	Queue store[Ncode];
	answer_t Answer;

	procedure entry answer_t query(request_t request, int type)
	{
		store[type].enqueue(request);
		handler[type].signal();
		applicant[type].wait();
	}

	procedure entry request_t getquery(int index, int *type)
	{
		int max = 0;
		*type = -1;

		if (store[index].Count > 0)
			*type = index;
		else
			for (int i = 0; i < N; i++)
				if (store[i].Count > max)
				{
					*type = i;
					max = store[i].Count;
				}
		if (*type == -1)
			handler[index].wait();
		return store[*type].dequeue();
	}

	procedure entry void reply(int type, answer_t answer)
	{
		Answer = answer;
		applicant.signal();
	}
}