def csEnter(id):
	if channel_join_create(id) == 1:
		channel_send(id, Free)
	channel_receive(id)

def csExit(id):
	channel_leave_delete(id)
	channel_send(id, Free)