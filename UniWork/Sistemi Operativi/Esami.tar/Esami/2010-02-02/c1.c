monitor abracadabra
{
	char pattern[] = { 'A', 'B', 'R', 'A', 'C', 'A', 'D', 'A', 'B', 'R', 'A' };
	int i = 0;
	stopped = {} // Python-like dictionary
	
	procedure entry init(char actual)
	{
		if (actual != pattern[i])
			stopped.get(actual, condition()).wait();
	}
	
	procedure entry synchro(actual)
	{
		if (actual != pattern[i])
		{
			if (stopped[pattern[i]])
				stopped[pattern[i]].signal();
			stopped[actual].wait();
		}
		i = (i + 1) % pattern.Length;
	}
}
