psend(dest, prio, msg)
{
	asend(dest, (MSG, getpid, prio, msg)));
}

precv(sender)
{
	asend(getpid, (NULLTAG, getpid, NULL, NULL));
	do
	{
		(tag, senderx, prio, msg) = arecv(*);
		if (tag == MSG)
			msgdb.add(senderx, prio, msg);
	} while (tag != NULLTAG);
	while (!(m = msgdb.getMaxPrio(sender)))
	{
		(tag, senderx, prio, msg) = arecv(*);
		msgdb.add(senderx, prio, msg);
	}
	return m;
}