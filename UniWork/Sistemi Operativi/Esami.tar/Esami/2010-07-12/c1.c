monitor priocoop
{
	condition ok[10];
	waiting[10] = 0;
	bool running = False;
	
	int getHighest()
	{
		for (i = 9; i >= 0; i--)
			if (waiting[i] > 0)
				return i;
		return -1;
	}
	
	init(p)
	{
		if (running)
		{
			waiting[p]++;
			ok[p].wait();
			waiting[p]--;
		}
		running = True;
	}
	
	yield(p)
	{
		i = getHighest();
		if (i >= 0)
			ok[i].signal();
		waiting[p]++;
		running = False;
		ok[p].wait();
		running = True;
		waiting[p]--;
	}
	
	fini()
	{
		running = False;
		i = getHighest();
		if (i >= 0)
			ok[i].signal();
	}
}
