monitor immigration01
{
	condition citizen[2];
	int immigrants[2] = {0, 0};

	void emigrate(int i)
	{
		if (immigrants[i] == MAXIMM || immigrants[1 - i] == MAXIMM)
			citizen[i].wait();
		immigrants[i]++;
	}

	void returnhome(int i)
	{
		immigrants[i]--
		citizen[i].signal();
	}
}