I = 0
T = 1
A = 2
L = 3
expected = [I, T, A, L, I, A]
index = 0
def sinc(actual):
	prev = (index - 1) % 6
	if expected[prev] == actual:
		asend(expected[index], index)
	index = (arecv(*) + 1) % 6