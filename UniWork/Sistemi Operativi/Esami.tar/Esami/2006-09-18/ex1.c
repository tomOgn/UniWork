monitor blq
{
	int waitingT[4] = {0, 0, 0, 0};
	int waitingC = 0;
	condition taxi[4];

	void wait4cust()
	{	
		if (waitingC > 0)
		{
			waitingC--;
			customer.signal();
		}
		else
		{
			int n = random(1, 4);
			waitingT[n]++;
			taxi[n].wait();			
		}
	}

	void wait4taxi()
	{
		for (int i = 0; i < 3; i++)
		{
			if (waitingT[i] > 0)
			{
				waitingT[i]--;
				taxi[i].signal();
				return;
			}
		}
		waitingP++;
		customer.wait();
	}
}