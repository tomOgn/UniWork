msg exchange(msg m)
{
	asend(<(i+1)%N, m>, server);
	return arecv(server);
}

process server()
{
	int ready = 0;
	DataBase db;

	while (true)
	{
		<i, m> = arecv(*);
		db.insert(<i, m>);
		ready++;
		if (ready == N)
		{
			while (ready > 0)
			{
				ready--;
				<i, m> = db.retrieve(<ready, ?>);
				asend(i, m);
			}
		}
	}
}