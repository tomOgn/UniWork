monitor coopsched
{
	condition process;
	bool running = false;
	int count = 0;

	procedure entry init()
	{
		if (running)
			process.wait();
		count++;
		running = true;
	}
	
	procedure entry fini()
	{
		if (--count == 0)
			running = false;
		else
			process.signal();
	}
	
	procedure entry yield()
	{
		if (count == 1) return;
		process.signal();
		process.wait();
	}
}