monitor nmbb
{
	condition writer, reader;
	queue buffer, readSize, writeSize;
	
	procedure entry write(int n, struct elem *v)
	{
		if (n > BUFSIZE) return;
		
		if (n + buffer.Count > BUFSIZE)
		{
			waitingWriters++;
			writeSize.enqueue(n);
			writer.wait();
			writeSize.dequeue();
			waitingWriters--;
		}
		
		for (int i = 0; i < n; i++)
			buffer.enqueue(v[i]);
		
		if (waitingWriters > 0 && (writeSize.top() + buffer.Count <= BUFSIZE))
			writer.signal();
		else if (waitingReaders > 0 && (readSize.top() <= buffer.Count))
			reader.signal();
	}
	
	procedure entry read(int m, struct elem *w)
	{
		if (m > BUFSIZE) return;
		
		if (m > buffer.Count)
		{
			waitingReaders++;
			readSize.enqueue(m);
			reader.wait();
			readSize.dequeue();
			waitingReaders--;
		}
			
		for (int i = 0; i < m; i++)
			w[i] = buffer.dequeue();
			
		if (waitingReaders > 0 && (readSize.top() <= buffer.Count))
			reader.signal();
		else if (waitingWriters > 0 && (writeSize.top() + buffer.Count <= BUFSIZE))
			writer.signal();
	}
}
