// foo(x, y)
int global = 1;

csEnter:
	do
	{
		int local;
		bravo(local, global);
	} while (local != 2);

csExit:
	global = 1;

// bar(z, t)
bool global = true;

csEnter:
	do
	{
		bool local = false;
		bar(local , global);
	} while (!local);

csExit:
	global = true;