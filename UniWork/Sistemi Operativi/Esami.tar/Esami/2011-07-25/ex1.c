monitor shufflebb
{
	queue buffer;
	deque triple;
	countBuffer = 0;
	countTriple = 0;
	
	procedure entry void write(T elem)
	{
		if (countBuffer + countTriple == 3 * MAX)
		{
			waitingWrite++;
			okWrite.wait();
			waitingWrite--;
		}
		if (countTriple < 3)
		{
			triple.append(elem);
			countTriple++;
		}
		else
		{
			for (i = 0; i < 3; i++)
				buffer.enqueue(triple.popleft());
			countBuffer += 3;
			okRead.signal();
			okRead.signal();
			okRead.signal();
		}
	}
	
	procedure entry T read(void)
	{
		if (countBuffer == 0)
		{
			waitingRead++;
			okRead.wait();
			waitingRead--;
		}
		countBuffer--;
		output = buffer.dequeue();
		okWrite.signal();
		return output;
	}
}
