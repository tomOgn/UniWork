adoublesend(msg, dst1, dst2)
{
	asend(msg, dst1);
	arecv(dst1);
	asend(msg, dst2);
}

adoublerecv(sender)
{
	output = arecv(sender);
	asend(OK, sender);
	return output;
}