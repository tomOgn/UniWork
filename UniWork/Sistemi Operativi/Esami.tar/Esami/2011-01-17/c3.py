unreceived = {} # Python-like dictionary

def iareceive(sender):
	output = arecv(sender)
	unreceived[getpid()] -= 1
	return output

def iasend(destination, message):
	unreceived[destination] = unreceived.get(destination, 0) + 1
	asend(message, destination)
	return unreceived[destination]