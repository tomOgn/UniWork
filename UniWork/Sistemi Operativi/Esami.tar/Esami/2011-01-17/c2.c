// lfsem by means of counting semaphore
class lfsem
{
private:
	double value = 1;
	queue denominator;
public:
	void frac(double x)
	{
		if (value / x < 1)
		{
			denominator.enqueue(x);
			semaphore.P();
		}
		value /= x;
		if (value / denominator.first() >= 1)
		{
			denominator.dequeue();
			semaphore.V();
		}
	}
};
// counting semaphore by means of lfsem
class semaphore
{
private:
	int value = 1;
public:
	P()
	{
		
	}

	V()
	{

	}
};