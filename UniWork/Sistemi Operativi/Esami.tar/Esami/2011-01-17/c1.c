monitor reqq
{
	Queue pending;
	condition handler, applicant;
	answer_t output;

	answer_t query(request_t request)
	{
		pending.enqueue(request);
		handler.signal();
		applicant.wait();
		return output;
	}

	request_t getquery()
	{
		if (pending.Count == 0)
			handler.wait();
		return pending.dequeue();
	}

	void reply(answer_t answer)
	{
		output = answer;
		applicant.signal();
	}
}