monitor palindrome5
{
	class Stopped
	{
		condition Queue;
		int Count = 0;
	};
	
	Stopped stopped[10];
	int length = 0;
	int palindrome[10];
	repeated = {} // Python-like dictionary
	
	synch(int actual)
	{
		if (length == 10)
		{
			length = 0;
			repeated = {};
		}
		if (length < 5)
		{
			if (repeated[actual])
			{
				stopped[actual].Count++;
				stopped[actual].Queue.wait();
				stopped[actual].Count--;
			}
			palindrome[length++] = actual;
			repeated[actual] = true;
		}
		else
		{
			int expected = palindrome[n - 5];
			if (stopped[expected].Count > 0)
			{
				stopped[number].Queue.signal();
				stopped[actual].Count++;
				stopped[actual].Queue.wait();
				stopped[actual].Count--;
			}		
			else if (expected != actual)
			{
				stopped[actual].Count++;
				stopped[actual].Queue.wait();
				stopped[actual].Count--;				
			}
			palindrome[n++] = index;
		}
	}
}
