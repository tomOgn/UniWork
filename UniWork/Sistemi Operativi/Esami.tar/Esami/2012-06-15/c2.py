def sx2sencd(msg, dest1, dest2):
	asend((SND, getpid(), dest1, dest2, msg), server)
	arecv(server)

def sx2receive(sender):
	asend((RCV, getpid(), sender, None, None), server)
	return arecv(server)

"""
searchPending(pending, source, destination)
	@summary: search a pending message and remove it from the list.
			  Return the message in case of success, False otherwise.
"""

def process server():
	waiting = set() # Python-like set
	pending = []

	while (True):
		(tag, source, dest1, dest2, msg) = arecv(*)
		if tag == SND:
			if (source, dest1) in waiting:
				asend(msg, dest1)
				asend(ACK, source)
				waiting.remove((source, dest1))
			elif (source, dest2) in waiting:
				asend(msg, dest2)
				asend(ACK, source)
				waiting.remove((source, dest2))
			else:
				pending.append((source, dest1, dest2, msg))
		else:
			destination = source
			source = dest1
			if (msg = searchPending(pending, source, destination)):
				asend(msg, destination)
				asend(ACK, source)
			else:
				waiting.add((source, destination))
