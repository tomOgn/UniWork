monitor dualwriter
{
	Queue buffer1, buffer2;
	condition writer, reader1, reader2;
	int waitingWriters, waitingReaders1, waitingReaders2;

	waitingWriters = waitingReaders1 = waitingReaders2 = 0;

	procedure entry void write(type1 e1, type2 e2)
	{
		if (buffer1.Count == BUFSIZE || buffer2.Count == BUFSIZE)
		{
			waitingWriters++;
			writer.wait();
			waitingWriters--;
		}
		buffer1.enqueue(e1);
		buffer2.enqueue(e2);
		if (waitingReaders1.Count > 0)
			reader1.signal();
		if (waitingReaders2.Count > 0)
			reader2.signal();		
	}

	procedure entry type1 read1()
	{
		if (buffer1.Count == 0)
		{
			waitingReaders1++;
			reader1.wait();
			waitingReaders1--;
		}
		type1 output = buffer1.dequeue();
		if (waitingWriters > 0 && buffer2.Count < BUFSIZE)
			writer.signal();
		return output;
	}

	procedure entry type2 read2()
	{
		if (buffer2.Count == 0)
		{
			waitingReaders2++;
			reader2.wait();
			waitingReaders2--;
		}
		type2 output = buffer2.dequeue();
		if (waitingWriters > 0 && buffer1.Count < BUFSIZE)
			writer.signal();
		return output;
	}	
}