Monitor bufbuf
{
	Queue buffer, enqueueN, dequeueN;
	Condition enqueueRequest, dequeueRequest;

	void enqueue(int n, Type *v)
	{
		if (buffer.Count + n > NELEM)
		{
			enqueueN.enqueue(n);
			enqueueRequest.wait();
		}

		for (int i; i < n; i++)
			buffer.enqueue(v[i]);
		
		if (buffer.Count >= dequeueN.first())
		{
			dequeueN.dequeue();
			dequeueRequest.signal();
		}
	}

	void dequeue(int n, Type *v)
	{
		if (buffer.Count - n < 0)
		{
			dequeueN.enqueue(n);
			dequeueRequest.wait();		
		}

		for (int i; i < n; i++)
			v[i] = buffer.dequeue();

		if (buffer.Count + enqueueN.first() <= NELEM)
		{
			enqueueN.dequeue();
			enqueueRequest.signal();			
		}
	}
}