Message msgxchange(pid_t pid, Message msg)
{
	asendx(pid, (getpid(), msg));
	while (!(msg2 = db.get(pid)))
		db.put(arecvx());
	return msg2;
}
