monitor bridge
{
	condition vehicle[2];
	int n, dir;
	int waiting[2];

	n = waiting[0] = waiting[1] = direction = 0;

	procedure entry enter(int inDir)
	{
		if (n == N || 
			(dir != inDir && n > 0) || 
			(dir == inDir && waiting[1 - inDir] > 0))
		{
			waiting[inDir]++;
			vehicle[inDir].wait();
			waiting[inDir]--;
		}
		dir = inDir;

		if (++n < N && waiting[inDir] > 0 && waiting[1 - inDir] == 0)
			vehicle[inDir].signal();
	}

	procedure entry exit(int outDir)
	{
		if (--n == 0)
		{
			if (waiting[outDir] > 0)
				vehicle[outDir].signal();
			else if (waiting[1 - outDir] > 0)
				vehicle[1 - outDir].signal();
		}
	}
}