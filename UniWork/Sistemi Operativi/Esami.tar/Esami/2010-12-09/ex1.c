monitor shufflebb
{
	void write(T elem)
	{
		
	}

	T read(void)
	{
		
	}
}