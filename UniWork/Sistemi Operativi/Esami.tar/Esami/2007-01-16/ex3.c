propose(m, id)
{
	ssend(m, id)
	return srecv(id)
}

proposal = { } # Python-like dictionary
accept(n)
{
	while True:
		m, id = srecv(*)
		proposal[m] = proposal.get(m, []) + [id]
		if proposal[m].length == n:
			break
	for key, value in proposal.items():
		answer = 1 if key == m else 0
		for id in value:
			ssend(answer, id)
}

# ----------------------------------------------

propose(m, id)
{
	asend(m, id)
	return arecv(id)
}

proposal = { } # Python-like dictionary
accept(n)
{
	while True:
		m, id = arecv(*)
		proposal[m] = proposal.get(m, []) + [id]
		if proposal[m].length == n:
			break
	for key, value in proposal.items():
		answer = 1 if key == m else 0
		for id in value:
			asend(answer, id)
}

