monitor Supermercato
{
	const int Pane = 0, Pesce = 1;
	Queue prenotazione[2];
	condition cliente;
	int Banco;
	bool commessoFermo = false;
	/*
		Find an element within a queue.
		Input:  pid,   the element to find
		        queue, the queue to analyse
		Output: true,  if the element is found
		        false, else
	*/
	bool find(int pid, Queue queue);

	void prendi_numero(int banco)
	{
		prenotazione[banco].enqueue(getpid());
	}

	int attendi()
	{
		int pid = getpid();

		if (!find(pid, prenotazione[Pane]) && !find(pid, prenotazione[Pesce]))
			return -1;
		inAttesa.enqueue(pid);

		if (commessoFermo)
			commesso.signal();
		else
			cliente.wait();

		return Banco;
	}

	void servi_il_prossimo(int banco)
	{
		if (inAttesa.Count == 0)
		{
			commessoFermo = true;
			commesso.wait();
		}
		commessoFermo = false;

		clienteDisponibile = inAttesa.dequeue();
		while (clienteDisponibile != prenotazione[banco].dequeue());
		Banco = banco;
		cliente.signal();
	}
}