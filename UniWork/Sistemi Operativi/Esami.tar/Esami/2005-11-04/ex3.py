global = 3

CSenter:
	while True:
		local = 2
		QR(global, local) # QR(x,y) = <y1=x%y; x1=x/y; x=x1; y=y1;>
		if local == 3/2:
			break

CSexit:
	global = 3

'''
Osservazioni:
(1) La funzione atomica risulta idonea a sostituire la Test&Set.
(2) La variabile globale assume i seguenti valori:
    3, quando la Critical Section e' libera;
    1, quando la Critical Section e' !libera.
(3) Si alternano i seguenti 4 stati (<global, local>):
   (da libero ad occupato)   <3, 2> --> <1, 3/2>
   (da occupato ad occupato) <1, 2> --> <1, 1/2>
'''