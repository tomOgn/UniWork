def ssend2(m, d1, d2):
	msg = ( SND, getpid(), d1, d2, m )
	asend(msg, server)
	return arecv(server)

def sreceive():
	msg = ( RCV, getpid(), None, None, None )
	asend(msg, server)
	return arecv(server)

def server():
	while True:
		flag, src, d1, d2, msg = arecv(*)
		if flag == RCV:
			msg, sender, _, _ = dbSnd.retrieve(query = '(?, ?, src, ?) or (?, ?, ?, src)')
			if msg:
				asend(msg, src)
				asend(src, sender)
			else:
				dbRcv.insert(src)
		else:
			if dbRcv.retrieve(d1):
				asend(msg, d1)
				asend(d1, src)
			elif dbRcv.retrieve(d2):
				asend(msg, d2)
				asend(d2, src)
			else:
				dbSnd.insert((msg, src, d1, d2))