monitor casino
{
	bool playing, exEquo;
	int max, n, leaving, waiting;
	condition wantToPlay, player;

	playing = exEquo = false;
	n = waiting = 0;

	void misiedo()
	{
		if (playing)
		{
			waiting++;
			wantToPlay.wait();
			waiting--;
		}
		if (++n < 5)
			player.wait();
		else
		{
			playing = true;
			max = 0;		
		}
		player.signal();
	}

	int gioca(int number)
	{
		if (number == max)
			exEquo = true;
		else if (number > max)
		{
			exEquo = false;
			max = number;
		}	
		if (--n > 0)
			player.wait();
		else
			leaving = 5;
		player.signal();
		return (!exEquo && number == max)? 4 : -1;
	}

	void mialzo()
	{
		if (--leaving == 0)
		{	
			while (waiting > 0 && n < 4)
				wantToPlay.signal();
			
			if (waiting > 0)
				wantToPlay.signal();
			else
				playing = false
		}
	}
}