monitor mvie
{
	int waitingProducer, waitingConsumer;
	condition producer, consumer;
	queue buffer[M];

	waitingProducer = waitingConsumer = 0;

	procedure entry void put(generic *object)
	{
		if (someFull())
		{
			waitingProducer++;
			producer.wait();
			waitingProducer--;
		}
		for (int i = 0; i < M; i++)
			buffer[i].enqueue(object[i]);
		if (!someFull() && waitingProducer > 0)
			producer.signal();
		else if (!someEmpty() && waitingConsumer > 0)
			consumer.signal();
	}

	procedure entry generic *get(int n)
	{
		if (someEmpty())
		{
			waitingConsumer++;
			consumer.wait();
			waitingConsumer--;
		}
		generic output = buffer[n].dequeue();
		if (!someEmpty() && waitingConsumer > 0)
			consumer.signal();
		else if (!someFull() && waitingProducer > 0)
			producer.signal();
	}
}
