class BinarySemaphore
{
	private int value;
	Queue queue0 = new Queue();
	Queue queue1 = new Queue();
	BinarySemaphore() { value = 1; }

	void P()
	{
		// [enter CS]
		int pid = <process id>;
		if (value == 0)
		{
			queue0.add(pid);
			suspend(pid);
		}
		value--;
		if (queue1.size() > 0)
		{
			int pid = queue1.remove();
			wakeup(pid);
		}
		// [exit CS]
	}

	void V()
	{
		// [enter CS]
		int pid = <process id>;
		if (value == 1)
		{
			queue1.add(pid);
			suspend(pid);
		}
		value++;
		if (queue0.size() > 0)
		{
			int pid = queue0.remove();
			wakeup(pid);
		}
		// [exit CS]
	}	
}