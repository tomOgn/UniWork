/* Risulta necessario un PROCESS SERVER. */

Message sendreceive(int dst, Message msg)
{
	ssend(<getpid(), dst, msg>, server);
	return sreceive(server);
}

process server()
{
	int waiting[][];
	Queue queue[][];
	while (True)
		handleMessage();
}

void handleMessage()
{
	<src, dst, msg> = sreceive(*);
	if (waiting[dst, src] > 0)
	{
		msg2 = queue[dst, src].dequeue();
		ssend(msg2, src);
		ssend(dst, msg);
		waiting[dst, src]--;
	}
	else
	{
		waiting[src, dst]++;
		queue[src, dst].enqueue(msg);
	}
}
