/* 
Starvation:
	IF { direzione iniziale D } AND { sussiste sempre in attesa un processo con direzione D } THEN 
		{ processi con direzione !D verranno sospesi e mai riattivati }

Correzione:
*/

monitor foo
{
	#define MAX 256;
	condition entercond[2];
	int waiting[2];
	int passing[2];
	int direction = -1;
	
	procedure entry enterfoo(int d)
	{
		if (direction < 0) direction = d;
	
		if (passing[d] == MAX || direction != d)
		{
			waiting[d]++;
			entercond[d].wait();
			waiting[d]--;
		}
	
		passing[d]++;
		if (waiting[d] > 0)
			entercond[d].signal();
	}

	procedure entry exitfoo()
	{
		passing[direction]--;
		if (waiting[1 - direction] > 0)
		{
			if (passing[direction] == 0)
			{
				direction = 1 - direction;
				entercond[direction].signal();
			}
		}
		else if (waiting[direction] > 0) // Evitabile => eventuale SIGNAL a vuoto
		{
			entercond[direction].signal();
		}
	}
}