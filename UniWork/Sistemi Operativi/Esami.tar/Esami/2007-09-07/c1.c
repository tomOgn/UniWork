monitor fabbrica
{
	Queue ruote, scocche;
	condition produttoreRuota, produttoreScocca, assemblatore;

	void deposita_ruota(Ruota r)
	{
		if (ruote.Count == 64)
			produttoreRuota.wait();

		ruote.enqueue(r);

		if (ruote.Count >= 4 && scocche.Count >= 1)
			assemblatore.signal();
	}

	void deposita_scocca(Scocca s)
	{
		if (scocche.Count == 8)
			produttoreScocca.wait();

		scocche.enqueue(s);

		if (ruote.Count >= 4)
			assemblatore.signal();
	}

	void preleva_pezzi(Ruota r[4], Scocca *s)
	{
		if (ruote.Count < 4 || scocche.Count < 1)
			assemblatore.wait();

		for (int i = 0; i < 4; i++)
			r[i] = ruote.dequeue();
		*s = scocche.dequeue();

		for (int i = 0; i < 4; i++)
			produttoreRuota.signal();
		produttoreScocca.signal();
	}
}