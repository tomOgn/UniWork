// f1(x, y)
int global = 64;

csEnter:
	do
	{
		int local;
		foo(local, global);
	} while (local != 0);

csExit:
	global = -2;

// bar(z, t)
int global = 0;

csEnter:
	do
	{
		int local = 1;
		bar(local, global);
	} while (local != 0);

csExit:
	global = 0;