// (1) Yes, it is possible.

void nbSend(Message msg, Pid dst)
{
	asend(<msg, getpid()>, dst);
}

Message nbReceive(Pid src)
{
	Message fake = Message();
	asend(fake, getpid());
	<msg, pid> = areceive(*);
	
	return (pid == src)? msg : NULL;
}

// (2) Yes, it is possible, but it requires busy waiting.

void aSend(Message msg, Pid dst)
{
	nbsend(msg, dst);
}

Message aReceive(Pid sender)
{
	Message msg;

	// Blocking effect through busy waiting
	while (!(msg = nbreceive(sender)));

	return msg;
}