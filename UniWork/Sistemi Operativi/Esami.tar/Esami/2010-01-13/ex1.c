Monitor lifobuf
{
	Deqeue buffer; // double-ended queue
	condition producer; // with a double-ended queue
	condition consumer;
	int waitingProducers = 0;
	
	void put(Element x)
	{
		if (buffer.Count == MAX)
		{
			waitingProducers++;
			producer.wait();
		}
		buffer.enqueue(x);
		consumer.signal();
	}

	Element get()
	{
		if (buffer.Count == 0)
		{
			if (waitingProducers > 0)
			{
				waitingProducers--;
				producer.signal();
			}
			else
				consumer.wait();
		}
		Element output = buffer.pop();
		producer.signal();
		return output;
	}
}
