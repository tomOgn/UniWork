rmpsend(dest, msg)
{
	if (!arecv(dest)) return;
	asend(msg, dest);
}

rmprecv(sender)
{
	asend(ACK, sender);
	return arecv(sender);
}