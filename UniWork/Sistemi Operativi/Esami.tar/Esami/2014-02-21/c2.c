// alpha(x, y)
// Non impiegabile in quanto restituisce valori costanti, indipendenti dall'input.
// Quindi non consente di distinguere tra i 2 stati (CS libera xor CS occupata).

// bravo(x, y)
int global = 0;

csEnter:
	do
	{
		int local = 2;
		bravo(global, local);
	} while (local == 2);

csExit:
	global = 0;

// charlie(x, y)
int global = 1;

csEnter:
	do
	{
		int local = 16;
		charlie(local , global);
	} while (local == 16);

csExit:
	global = 1;

// delta(z, t)
bool global = false;

csEnter:
	do
	{
		bool local = true;
		delta(local, global);
	} while (!local);

csExit:
	global = false;