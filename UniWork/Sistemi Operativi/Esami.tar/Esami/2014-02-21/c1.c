/*
Nota: i contatori svolgono la sola funzione di evitare (inutili) signal a vuoto.
*/
monitor bbwl
{
	int waitingWriters, waitingLoggers, waitingReaders;
	condition writer, reader, logger;
	queue logged, written;

	waitingWriters = waitingLoggers = waitingReaders = 0;

	procedure entry void write(eltype elem)
	{
		if (written.Count + logged.Count == MAXELEM)
		{
			waitingWriters++;
			writer.wait();
			waitingWriters--;
		}
		written.enqueue(elem);
		if (waitingLoggers > 0)
			logger.signal();
	}

	procedure entry eltype log()
	{
		if (written.Count == 0)
		{
			waitingLoggers++;
			logger.wait();
			waitingLoggers--;
		}
		logged.enqueue(written.dequeue());
		eltype output = logged.top();
		if (waitingReaders > 0)
			reader.signal();
		return output;
	}

	procedure entry eltype read()
	{
		if (logged.Count == 0)
		{
			waitingReaders++;
			reader.wait();
			waitingReaders--;
		}
		eltype output = logged.dequeue();
		if (waitingWriters > 0)
			writer.signal();
		return output;
	}
}