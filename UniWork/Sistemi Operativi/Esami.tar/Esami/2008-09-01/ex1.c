Monitor duetrequattro
{
	condition process;
	int running, waiting;

	running = waiting = 0;

	void enter()
	{
		if (running > 0 || (running == 0 && waiting < 3))
		{
			waiting++;
			process.wait();
			waiting--;
			running++;
		}
		else
		{
			for (int i = 0; i < 3; i++)
				process.signal();
			running = 4;
		}
	}

	void exit()
	{
		running--;
		if (running == 0 && waiting >= 2)
		{
			for (int i = 0; i < waiting && i < 4; i++)
				process.signal();
		}
	}
}