void ssend(pid_t dest, string msg)
{
	foreach (char c in msg)
		msgsend1(dest, c);
	msgsend1(dest, null); // message terminator
	msgrecv1(dest);
}

string srecv(pid_t sender)
{
	string output = "";
	char piece = msgrecv1(sender);
	while (piece)
	{
		output += piece;
		piece = msgrecv1(sender);
	}
	msgsend1(dest, null);
}