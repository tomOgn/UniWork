Process server[j]()
{
	while (true)
	{
		for (int i = 0; i < N && i != j; i++)
		{
			Message msg = arecv(server[i]);
			if (msg)
				print(msg);
		}
	}
}