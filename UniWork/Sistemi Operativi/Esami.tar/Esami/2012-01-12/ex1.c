monitor seq
{
	Stack process;
	stopped = {}; // Python-like dictionary
	
	procedure entry void enter()
	{
		process.push(getpid());
	}
	
	procedure entry void exit()
	{
		expected = process.top();
		actual = getPid();
		if (actual != expected)
		{
			if (stopped[expected])
				stopped[expected].signal();
			stopped.get(actual, condition()).wait();
		}
		process.pop();
	}
}
