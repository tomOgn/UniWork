monitor Vallettopoli
{
	void chiedi_raccomandazione(pid dirigente)
	{
		
	}

	int appari(void)
	{

	}


}