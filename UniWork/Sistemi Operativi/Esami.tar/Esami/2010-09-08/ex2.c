stx_send(dst, msg, timeout)
{
	if (!srx_recv(dst, timeout)) return;
	srx_send(dst, msg);
}

stx_recv(sender)
{
	srx_send(sender, ACK);
	srx_recv(sender, 0);
}