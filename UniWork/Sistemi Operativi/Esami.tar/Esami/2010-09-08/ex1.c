monitor dualbb
{
	enum buf {0, 1};
	queue buffer[2];
	condition getter[2], putter;
	
	void put(buf t, T item)
	{
		if (buffer[t].Count == MAX)
			putter.wait();
		buffer[t].enqueue(item);
		getter[t].signal();
	}
	
	T get (buf t)
	{
		if (buffer[t].Count == 0)
		{
			if (buffer[1 - t].Count > 0)
			{
				output = buffer[1 - t].dequeue();
				putter[1 - t].signal();
				return output;
			}
			else
				getter[t].wait();
		}
		output = buffer[t].dequeue();
		putter[t].signal();
		return output;
	}
}
