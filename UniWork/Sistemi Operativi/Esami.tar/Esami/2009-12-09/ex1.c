/*
 * URL: http://www.cs.unibo.it/~renzo/so/compiti/2009-12-09.con.pdf
 * author: Tommaso Ognibene
*/

monitor abracadabra
{
	expected = ['T', 'A', 'R', 'A', 'T', 'A', 'T', 'A'];
	i = 0;
	stopped = {} // Python-like dictionary
	
	procedure entry synchro(actual)
	{
		if (actual != expected[i])
		{
			if (stopped[expected[i]])
				stopped[expected[i]].signal();
			stopped.setdefault(actual, condition()).wait();
		}
		if (++i == expected.Length)
			i = 0;
	}
}
