Semaphore sem = 0;

void ssend(T msg, pid_t dest)
{
	P(S);
	while (!writeable)
	{
		
	}
	local = n;
	writeable = false;
	notify();
}

void sreceive(T *pmsg, pid_t sender)
{
 while (writeable)
 {
 
 }
 writeable = true;
 return(local);
}
