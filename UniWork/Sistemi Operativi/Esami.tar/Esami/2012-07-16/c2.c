// bool1 == bool5 == bool9 == bool13
bool global = false;

csEnter:
	do
	{
		bool local = true;
		bool1(local, global);
	} while (local);

csExit:
	global = false;

// bool2 == bool10 == bool14
bool global = false;

csEnter:
	do
	{
		bool local = true;
		bar(local, global);
	} while (!local);

csExit:
	global = false;

// bool4 == bool5 == bool6 == bool7
bool global = false;

csEnter:
	do
	{
		bool local = false;
		bar(local, global);
	} while (local);

csExit:
	global = false;