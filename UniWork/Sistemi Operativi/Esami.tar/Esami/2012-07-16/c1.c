monitor limcol
{
	condition okEnter, okExit;
	majority = minority = waitingEnter = waitingExit = 0;
	leadingColor;
	turn = true;
	
	procedure entry enter(color)
	{
		// [Case 1] First process
		if (majority == 0)
		{
			leadingColor = color;
			majority++;
		}
		// [Case 2] Leading color
		else if (color == leadingColor)
		{
			majority++;
		}
		// [Case 3] Non-Leading color
		else
		{
			// Stop if does not comply with the rule
			if ((minority + 1) / (majority + minority + 1) > 0.25)
			{
				waitingEnter++;
				okEnter.wait();
				waitingEnter--;
			}
			
			minority++;
		}
		
		// Alternate the priorities in order to avoid possible starvation
		if (turn)
		{
			// Add a non-leading color if this comply with the rule
			if ((minority + 1) / (majority + minority + 1) <= 0.25)
			{
				turn = false;
				okEnter.signal();
			}
					
			// Remove a leading color if this comply with the rule
			if ((majority - 1) / (majority - 1 + minority) >= 0.75 || majority == 1)
			{
				turn = false;
				okExit.signal();
			}
		}
		else
		{
			// Remove a leading color if this comply with the rule
			if ((majority - 1) / (majority - 1 + minority) >= 0.75 || majority == 1)
			{
				turn = true;
				okExit.signal();
			}
				
			// Add a non-leading color if this comply with the rule
			if ((minority + 1) / (majority + minority + 1) <= 0.25)
			{
				turn = true;
				okEnter.signal();
			}			
		}
	}
	
	procedure entry exit(color)
	{
		// [Case 1] Non-Leading color
		if (color != leadingColor)
		{
			minority--;
		}
		// [Case 2] Leading color
		else
		{
			// Stop if does not comply with the rule
			if ((majority - 1) / (majority - 1 + minority) < 0.75 && majority > 1)
			{
				stoppedExit++;
				okExit.wait();
				stoppedExit--;
			}
			
			majority--;
		}
		
		// Alternate the priorities in order to avoid possible starvation
		if (turn)
		{
			// Add a non-leading color if this comply with the rule
			if ((minority + 1) / (majority + minority + 1) <= 0.25)
			{
				turn = false;
				okEnter.signal();
			}
					
			// Remove a leading color if this comply with the rule
			if ((majority - 1) / (majority - 1 + minority) >= 0.75 || majority == 1)
			{
				turn = false;
				okExit.signal();
			}
		}
		else
		{
			// Remove a leading color if this comply with the rule
			if ((majority - 1) / (majority - 1 + minority) >= 0.75 || majority == 1)
			{
				turn = true;
				okExit.signal();
			}
				
			// Add a non-leading color if this comply with the rule
			if ((minority + 1) / (majority + minority + 1) <= 0.25)
			{
				turn = true;
				okEnter.signal();
			}			
		}
	}
}
