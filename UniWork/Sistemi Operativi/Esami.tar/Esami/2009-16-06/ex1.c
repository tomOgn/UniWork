monitor multiq
{
	queue queueRequests[N];
	answer_t Answer;
	condition requester[N];
	
	query(type, request)
	{
		queueRequests[type].enqueue(request);
		answerer[type].signal();
		requester[type].wait();
		return Answer;
	}

	request_t getquery(int i, int *type)
	{
		if (queueRequests[i].Count == 0)
			answerer[i].wait();
		*type = i;
		return queueRequests[i].dequeue();
	}

	reply(int i, answer_t answer)
	{
		Answer = answer;
		requester[i].signal();
	}
}