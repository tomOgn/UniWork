monitor eventp
{
	// Python-like dictionary
	writer = {}; reader = {};

	EP *create(unsigned value)
	{
		return new EP(Value = value);
	}

	void write(EP *d, unsigned value)
	{
		if (isOverflow(EP->Value + value))
			writer.setdefault(EP, new condition()).wait();
		EP->Value += value;
		if (reader[EP])
			reader[EP].signal();
	}

	unsigned read(EP *d)
	{
		unsigned output = EP->Value;
		if (output == 0)
			reader.setdefault(EP, new condition()).wait();	
		if (writer[EP])
			writer[EP].signal();
		EP->Value = 0;
		return output;
	}

	void close(ED *d)
	{
		writer.pop(EP);
		reader.pop(EP);
		delete ED;
	}
}