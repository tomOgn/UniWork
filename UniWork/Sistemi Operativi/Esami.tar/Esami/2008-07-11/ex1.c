monitor duetrequattro
{
	waiting = running = 0;
	condition ok;
	
	procedure entry enter()
	{
		if (running != 0 || (running == 0 && waiting < 3))
		{
			waiting++;
			ok.wait();
			waiting--;
		}
		running++;
		
		if (running < 4)
			ok.signal();
	}
	
	procedure entry exit()
	{
		running--;
		
		if (running == 0 && waiting >= 2)
			ok.signal();
	}
}
