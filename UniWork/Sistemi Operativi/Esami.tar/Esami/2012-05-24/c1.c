monitor santuario
{
	int Go = 1, Back = 0, visiting = 0;
	condition visitor[2];
	int crossing[2] = {0, 0}, waiting[2] = {0, 0};

	bool reachedMax()
	{
		return visiting + crossing[Go] == MAXSANTUARIO;
	}

	procedure entry entraponte(int dir)
	{
		if (crossing[dir] == MAXPONTE || 
		    (dir == Go && reachedMax()) || 
		    crossing[1 - dir] > 0) || 
		    waiting[1 - dir] > 0)
		{
			waiting[dir]++;
			visitor[dir].wait();
			waiting[dir]--;
		}
		crossing[dir]++;
		if (dir == Back)
			visiting--;
		if (waiting[Go] > 0 && !reachedMax())
			visitor[Go].signal();
		else if (waiting[Back] > 0)
			visitor[Back].signal();
	}

	procedure entry esciponte(int dir)
	{
		if (dir == Go)
			visiting++;
		
		if (--crossing[dir] == 0)
			visitor[1 - dir].signal();
	}
}
