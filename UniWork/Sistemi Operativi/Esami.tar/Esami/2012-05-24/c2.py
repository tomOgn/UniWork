def a2send(msg, dest1, dest2):
	asend((MSG, msg), dest1)
	asend((MSG, msg), dest2)
	tag, _ = arecv(dest1)
	if tag != ACK:
		exit(1) #deadlock
	tag, _ = arecv(dest2)
	if tag != ACK:
		exit(1) #deadlock
	
def s2recv(sender):
	tag, msg = arecv(sender)
	if tag != MSG:
		exit(1) #deadlock
	asend((ACK, None), sender)
	return msg;
