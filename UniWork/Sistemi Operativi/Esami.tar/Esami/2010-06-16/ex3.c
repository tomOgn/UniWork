I = 0; T = 1; A = 2; L = 3;

monitor Italia
{
	expected[] = { I, T, A, L, I, A };
	condition letter[4];
	int i = 0;

	print(actual)
	{
		if (actual != expected[i])
		{
			letter[expected[i]].signal();
			letter[actual].wait();			
		}
		if (++i == 6) i = 0;
	}
}

Process I:
while (true)
{
	Italia.print(I);
	print("I");
}

Process T:
while (true)
{
	Italia.print(T);
	print("T");
}

Process A:
while (true)
{
	Italia.print(A);
	print("A");
}

Process L:
while (true)
{
	Italia.print(L);
	print("L");
}