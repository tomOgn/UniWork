Semaphore I, T, A, L;
I = new Semaphore(2);
T = new Semaphore(1);
A = new Semaphore(0);
L = new Semaphore(1);

Process I:
while (true)
{
	I.P();
	I.P();
	I.P();
	print("I");
	I.V();
	T.V();
	A.V();
}

Process T:
while (true)
{
	T.P();
	T.P();
	print("T");
	I.P();
	A.V();
}

Process A:
while (true)
{
	A.P();
	A.P();
	print("A");
	L.V();
	I.V();
	I.V();
}

Process L:
while (true)
{
	L.P();
	L.P();
	print("L");
	I.V();
	A.V();
}