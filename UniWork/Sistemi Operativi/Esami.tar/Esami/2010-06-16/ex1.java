Monitor cartesio
{
	cartesio(xinit, yinit)
	{
		X = xinit;
		Y = yinit;		
	}

	PnB(x, y)
	{
		X -= x;
		Y -= y;
		
	}

	VnB(x, y)
	{

	}
}