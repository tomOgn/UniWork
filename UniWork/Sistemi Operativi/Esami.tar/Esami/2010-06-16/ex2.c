void barrier(int index)
{
	for (int i = 0; i < N && i != index; i++)
		asend("I'm in", P(i));
	for (int i = 0; i < N && i != index; i++)
		arecv(P(i));
}