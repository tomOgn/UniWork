class Triple
{
	pid_t Pids = []; # Python-like list
	condition Cond;
};

monitor three
{
	triple = {}; # Python-like dictionary

	def syn3(tag, proc):
		triple.setdefault(tag, Triple())
		triple[tag].Pids += [getpid()]
		if triple[tag].Pids.length < 3:
			triple[tag].Cond.wait()
		for pid in triple[tag].Pids:
			proc += [pid]
		triple[tag].Cond.signal();
}
