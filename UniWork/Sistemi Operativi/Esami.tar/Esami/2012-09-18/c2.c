"""
db is a database with the following methods:
(1) search(msg):
	@summary: search for a message
	@output: the sender's pid, or None if it is not found
(2) pop(pid, message):
	@summary: pop out a tuple (pid, message) from the dictionary
(3) insert(pid, message):
	@summary: insert a tuple (pid, message) in the dictionary
"""

def dsend(msg, pid):
	asend((getpid(), msg), pid)

def drecv():
	pid, msg = arecv(*)
	sender = db.search(msg)
	if sender and sender != pid:
		db.pop(sender, msg)
		return msg
	else:
		db.insert(pid, msg)