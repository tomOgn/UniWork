def fin(c):
	if c == '1':
		pattern = [ [1], [2], [3] ]
	elif c == '2':
		pattern = [ [2], [2], [2] ]
	else:
		pattern = [ [1], [1, 2], [1, 2] ]

	for options in pattern:
		for option in options:
			if waiting[option]:
				break;
			else:
				needing[option] = True
		if not waiting[option]:
			needing[option] = True
			semManager.P()
			needing[option] = False
		sem[option].V()
		for option in options:
			waiting[option] = False

def fout_pre(option):
	if not needing[option]:
		waiting[option] = True
		sem[option].P()
		waiting[option] = False

def fout_post(option):
	semManager.V()

