void fin(char c)
{
	if (c == '1')
	{
		if (waitingA == 0)
		{
			needingA++;
			needA.wait();
			needingA--;
		}
		printA.signal();
		if (waitingB == 0)
		{
			needingB++;
			needB.wait();
			needingB--;
		}
		printB.signal();
		if (waitingC == 0)
		{
			needingC++;
			needC.wait();
			needingC--;
		}
		printC.signal();
	}
	else if (c == '2')
	{
		for (int i = 0; i < 3; i++)
		{
			if (waitingB == 0)
			{
				needingB++;
				needB.wait();
				needingB--;
			}
			printB.signal();			
		}
	}
	else if (c == '3')
	{
		if (waitingC == 0)
		{
			needingC++;
			needC.wait();
			needingC--;
		}
		printC.signal();

		if (waitingA == 0 && waitingB == 0)
		{
			needingAB++;
			needAB.wait();
			needingAB--;
		}
		printC.signal();
	}
}