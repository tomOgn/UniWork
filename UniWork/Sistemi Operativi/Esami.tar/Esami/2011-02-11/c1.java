Monitor lifocs
{
	Stack process;
	boolean free = true;
	int waiting = 0;

	int enter()
	{
		if (!free)
		{
			waiting++;
			process.Push(new Condition())
			process.Top().wait();
			waiting--;
		}
		free = false;
		return waiting;
	}

	int exit()
	{
		free = true;
		int output = waiting;
		process.Pop().signal();
		return output;
	}
}