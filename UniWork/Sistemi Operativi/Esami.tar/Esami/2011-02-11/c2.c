// foo(void **x, void **y)
void **global = (void **) malloc(sizeof(void *));
*global = NULL;

csEnter:
	do
	{
		void **local = (void **) malloc(sizeof(void *));
		foo(local, global);
	} while (local);

csExit:
	*global = NULL;