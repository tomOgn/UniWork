Monitor eu
{
	const int Urgent = 1;
	int Code;
	condition doctor, patient[2];
	queue doctorName, patientName[2];
	
	Name getdoctor(Name name, int code)
	{
		patientName[code].enqueue(name);

		if ((code == Urgent && doctorName.Count == 0) || (code != Urgent && doctorName.Count < 4))
			patient[code].wait();
		else
		{
			Code = code;
			doctor.signal();
		}
		return doctorName.dequeue();
	}
	
	Name getpatient(Name name)
	{
		doctorName.enqueue(name);
		
		if (patientName[Urgent].Count == 0 && (patientName[1 - Urgent].Count == 0 || doctorName.Count < 4))
			doctor.wait();
		else
		{
			Code = (patientName[Urgent].Count > 0)? Urgent : 1 - Urgent;
			patient[Code].signal();
		}
		return patientName[Code].dequeue();
	}
}