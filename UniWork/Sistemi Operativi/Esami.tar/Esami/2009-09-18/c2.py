def recvdigest():
	messages = []
	asend(getpid(), BookMark)
	while (True):
		message = arecv(*)
		if message == BookMark:
			break
		messages += [message]
	if messages.length == 0:
		messages += [arecv(*)]
	return messages