Queue recvdigest()
{
	Queue buffer;
	asend(BookMark, getpid());
	message = arecv(*);
	if (message == BookMark)
		buffer.enqueue(arecv(*));
	else
	{
		do
		{
			buffer.enqueue(message);
			message = arecv(*);
		} until (message == BookMark)		
	}
	return buffer;
}