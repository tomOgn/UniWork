Shared:
	x = y = z = 1
	semaphore sem1, sem2, sem3, sem4
	sem1 = sem2 = sem3 = sem4 = 0

Process P
{
	while (1)
	{
		sem1.P();
		x = x + 1;
		sem2.V();
	}
}

Process Q
{
	while (1)
	{
		sem2.P();
		x = x + 1;
		sem3.V();
	}
}

Process R
{
	while (1)
	{
		sem3.P();
		y = y + x;
		sem4.V();
	}
}

Process S
{
	while (1)
	{
		if (z == y)
		{
			print(z)
			z = 0;
			sem1.V();
			sem4.P();
		}
		else
		{
			z = z + 1;
		}
	}
}