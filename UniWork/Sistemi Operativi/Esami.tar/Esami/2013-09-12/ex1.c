monitor lavatrice
{
	bool working;
	int waiting, quantity;
	condition user;

	waiting = quantity = 0;
	working = false;

	procedure entry enter()
	{
		if (working || waiting < 2)
		{
			waiting++;
			user.wait();
			waiting--;
		}
		working = true;
		quantity++;
		if (quantity < 5 && waiting > 0)
			user.signal();
	}

	procedure entry exit()
	{
		quantity = 0;
		if (waiting > 2)
			user.signal();
		else
			working = false;
	}
}