monitor nvie
{
	queue buffer[N];
	condition producer, consumer;
	int waitingProducer, waitingConsumer;

	waitingConsumer = waitingProducer = 0;

	bool halfNotEmpty()
	{
		int n = 0;
		for (int i = 0; i < N; i++)
			if (buffer[i].Count > 0)
				if (++n == N/2)
					return true;
		return false;
	}

	void put(int n, generic object)
	{
		if (buffer[n].Count == NELEM)
		{
			waitingProducer++;
			producer.wait();
			waitingProducer--;
		}
		buffer[n].enqueue(object)
		if (halfNotEmpty() && waitingConsumer > 0)
			consumer.signal();
	}

	void get(generic *object)
	{
		if (!halfNotEmpty())
		{
			waitingConsumer++;
			consumer.wait();
			waitingConsumer--;
		}
		for (int i = 0; i < N; i++)
			object[i] = (buffer[i].Count > 0)? buffer[i].dequeue() : NONE;
		if (waitingProducer > 0)
			producer.signal();
	}
}