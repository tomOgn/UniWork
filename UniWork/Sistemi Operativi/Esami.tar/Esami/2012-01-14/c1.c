monitor pbb
{
	stopped = {};
	buf = {};
	
	procedure entry enqueue(m, p)
	{
		if (buf.Size == SIZE)
			stopped.setdefault(p, condition()).wait();
		else
			priority[p] = priority;
	}
	
	procedure entry dequeue()
	{
		if (buf.Length == SIZE)
			priority.setdefault(prio, condition()).wait();
		else
			priority[prio] = priority;
	}
}
