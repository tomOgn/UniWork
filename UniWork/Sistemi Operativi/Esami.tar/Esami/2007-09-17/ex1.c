monitor dynamicBuffer
{
	queue buffer;
	unsigned int length = 1;

	void inserisci(T elem)
	{
		if (buffer.Count == length)
			insertion.wait();
		buffer.enqueue(elem);
		extraction.signal();
	}

	T estrai()
	{
		if (buffer.Count == 0)
			extraction.wait();
		output = buffer.dequeue(elem);
		insertion.signal();
		return output;			
	}

	void ampiezza(unsigned int N)
	{
		for (int i = 0; i + N < length; i++)
			buffer.dequeue();
		length = N;
	}
}