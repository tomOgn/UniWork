send2(msg m, pid rcv1, pid rcv2)
{
	asend(msg, rcv1);
	asend(msg, rcv2);
	arecv(rcv1);
	arecv(rcv2);
}

msg receive2(pid snd)
{
	
}